

const sideLinks = document.querySelectorAll('.sidebar .side-menu li a:not(.logout)');

sideLinks.forEach(item => {
    const li = item.parentElement;
    item.addEventListener('click', () => {
        sideLinks.forEach(i => {
            i.parentElement.classList.remove('active');
        })
        li.classList.add('active');
    })
});

const menuBar = document.querySelector('.content nav .bx.bx-menu');
const sideBar = document.querySelector('.sidebar');
const isSidebarClosed = localStorage.getItem('sidebarClosed');

// Disable transitions when the page loads
sideBar.classList.add('no-transition');

if (isSidebarClosed === 'true') {
    sideBar.classList.add('close');
}

// Re-enable transitions after a short delay
setTimeout(() => {
    sideBar.classList.remove('no-transition');
}, 100);

menuBar.addEventListener('click', () => {
    sideBar.classList.toggle('close');
    const isClosed = sideBar.classList.contains('close');
    localStorage.setItem('sidebarClosed', isClosed);
});


const searchBtn = document.querySelector('.content nav form .form-input button');
const searchBtnIcon = document.querySelector('.content nav form .form-input button .bx');
const searchForm = document.querySelector('.content nav form');


window.addEventListener('resize', () => {
    if (window.innerWidth < 768) {
        sideBar.classList.add('close');
    } else {
        sideBar.classList.remove('close');
    }
    if (window.innerWidth > 576) {
        searchBtnIcon.classList.replace('bx-x', 'bx-search');
        searchForm.classList.remove('show');
    }
});

const toggler = document.getElementById('theme-toggle');

// Function to toggle dark mode
function toggleDarkMode() {
    if (toggler.checked) {
        document.body.classList.add('dark');
        // Save the current state to localStorage
        localStorage.setItem('darkMode', 'true');
    } else {
        document.body.classList.remove('dark');
        // Save the current state to localStorage
        localStorage.setItem('darkMode', 'false');
    }
}

// Check localStorage on page load and apply dark mode if needed
window.addEventListener('load', function () {
    const isDarkMode = localStorage.getItem('darkMode') === 'true';
    if (isDarkMode) {
        toggler.checked = true;
        document.body.classList.add('dark');
    }
    
});

// Event listener for the dark mode toggle
toggler.addEventListener('change', toggleDarkMode);


const languageDropdown = document.getElementById('language-dropdown');
const currencyDropdown = document.getElementById('currency-dropdown');

const dropdownArrow = document.getElementById('dropdown-arrow');
const currencyDropdownArrow = document.getElementById('currency-dropdown-arrow');

dropdownArrow.addEventListener('click', () => {
  if (languageDropdown.style.display === 'none') {
    languageDropdown.style.display = 'block';
    dropdownArrow.classList.add('rotate');
  } else {
    languageDropdown.style.display = 'none';
    dropdownArrow.classList.remove('rotate');
  }
});

currencyDropdownArrow.addEventListener('click', () => {
  if (currencyDropdown.style.display === 'none') {
    currencyDropdown.style.display = 'block';
    currencyDropdownArrow.classList.add('rotate');
  } else {
    currencyDropdown.style.display = 'none';
    currencyDropdownArrow.classList.remove('rotate');
  }
});




const cardIcon=document.querySelector('.card-icon');
const cardClose=document.querySelector('.close');
const containerView=document.querySelector('.container-view');
const container=document.querySelector(".container");
// console.log(container);

// open the card
cardIcon.addEventListener('click',()=>{
    containerView.classList.add('open')
});
// close the card
cardClose.addEventListener('click',()=>{
    containerView.classList.remove('open')
});

// add the card

const containerCardView=document.querySelector(".container-card-view");
container.addEventListener('click',(e)=>{
    if(e.target.className==='btn'){
        let card=`
        <div class="card-view">
        <div class="div-image">
        <img src="${e.target.parentElement.parentElement.querySelector('img').src}">
        </div>
        <h2>${e.target.parentElement.parentElement.querySelector('h2').textContent}</h2>
        <div class="div-price-btn">
        <span class="price-view">${e.target.parentElement.querySelector('.price').textContent}</span>
        
        <button class="btn-remove">remove</button>
        </div>
        <input value="1" class="inp" type="number" min="1" max="12">
        </div>
        `;        
        containerCardView.innerHTML+=card;
        totalFun();
        // Quantity();
        removeCard();
    }
    
});

function Quantity(){
let inputQ=document.querySelectorAll('.inp');
for(let i=0; i<inputQ.length; i++){
    inputQ[i].addEventListener("click",changTotal);
}
}
function changTotal(){
    totalFun();
}



function totalFun(){
    let cardView=document.querySelectorAll('.card-view');
 total=0;
 if(cardView.length==0){
    let totalElement = document.querySelector('.span-total').innerHTML=0 ;
 }
    for(let i=0;i<cardView.length;i++){
         let price =parseInt(cardView[i].querySelector('.price-view').textContent);
         let inputValue=cardView[i].querySelector('.inp').value;
         total+=(price*inputValue);
         let totalElement = document.querySelector('.span-total').innerHTML=total +" $ ";
         Quantity();
        }
        cardIcon.innerHTML=cardView.length;
}

function removeCard(){
    let cardView=document.querySelectorAll('.card-view');
         for(let i=0;i<cardView.length;i++){
            cardView[i].querySelector('.btn-remove').addEventListener("click",(e)=>{
            e.target.parentElement.parentElement.remove();
            totalFun();
            })
         }
       
}









