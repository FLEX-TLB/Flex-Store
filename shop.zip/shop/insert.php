<?php

include('config.php');

if (isset($_POST['upload'])) {
    // Get form data
    $NAME = $_POST['name'];
    $PRICE = $_POST['price'];
    $CATEGORY = $_POST['category'];
    $BRAND = $_POST['brand'];
    $DESCRIPTION = $_POST['Description'];
    
    // Handle image upload
    $IMAGE = $_FILES['image'];
    $image_location = $_FILES['image']['tmp_name'];
    $image_name = $_FILES['image']['name'];

    // Define the target folder for each category
    $upload_folder = 'images/Products/' . $CATEGORY . '/' . $BRAND . '/';

    // Create the category folder if it doesn't exist
    if (!file_exists($upload_folder)) {
        mkdir($upload_folder, 0777, true); // Create the folder with write permissions
    }

    // Define the full path where the image will be saved
    $image_up = $upload_folder . $image_name;

    // Move the uploaded image to the target folder
    if (move_uploaded_file($image_location, $image_up)) {

        // Insert data into the database with the relative file path
        $insert = "INSERT INTO products (name, price, image, category, brand, description) 
                   VALUES ('$NAME', '$PRICE', '$image_up', '$CATEGORY', '$BRAND', '$DESCRIPTION')";
        
        // Execute the query
        if (mysqli_query($conn, $insert)) {
            // Redirect to the add page or show a success message
            header('Location: add.php');
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    } else {
        echo "Failed to upload image.";
    }
}
?>
