<?php
include 'config.php';
session_start();

$user_id = $_SESSION['user_id'] ?? null;
$message = [];

if (!$user_id) {
    header('location:login-out/login-out.php');
    exit();
}

if (isset($_GET['logout'])) {
    session_destroy();
    header('location:login-out/login-out.php');
    exit();
}

// Fetch user data from the database
$query = "SELECT * FROM user WHERE id = ?";
if ($stmt = $conn->prepare($query)) {
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $stmt->close();
} else {
    die("Error fetching user data: " . $conn->error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize inputs
    $name = htmlspecialchars($_POST['name'], ENT_QUOTES, 'UTF-8');
    $card_num = htmlspecialchars($_POST['card_num'], ENT_QUOTES, 'UTF-8');
    $image_path = $user['image']; // Default to existing image
    $password = $user['password']; // Default to the existing password

    // Update password if a new one is provided
    if (!empty($_POST['password'])) {
        $password = htmlspecialchars($_POST['password'], ENT_QUOTES, 'UTF-8'); // Use new password as plain text
    }

    // Handle file upload
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $image = $_FILES['image']['name'];
        $image_tmp_name = $_FILES['image']['tmp_name'];
        $upload_dir = 'us/';
        $image_path = $upload_dir . basename($image);

        // Validate image file type
        $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif'];
        $file_extension = strtolower(pathinfo($image, PATHINFO_EXTENSION));
        if (in_array($file_extension, $allowed_extensions)) {
            move_uploaded_file($image_tmp_name, $image_path);
        } else {
            echo "<script>alert('Invalid file type. Please upload a JPG, PNG, or GIF image.');</script>";
            $image_path = $user['image']; // Revert to existing image
        }
    }

    // Update user profile
    $update_query = "UPDATE user SET name = ?, password = ?, card_num = ?, image = ? WHERE id = ?";
    if ($update_stmt = $conn->prepare($update_query)) {
        $update_stmt->bind_param("ssssi", $name, $password, $card_num, $image_path, $user_id);
        $update_stmt->execute();
        $update_stmt->close();
        echo "<script>window.location.href='profile.php';</script>";
        exit();
    } else {
        die("Error updating profile: " . $conn->error);
    }
}


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/iconoir-icons/iconoir@main/css/iconoir.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/remixicon/3.5.0/remixicon.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="profile.css">

    <title>Flex Store</title>
    <script>
        window.addEventListener('load', function () {
            const isDarkMode = localStorage.getItem('darkMode') === 'true';
            const body = document.body;

            if (isDarkMode) {
                body.classList.add('dark');
            } else {
                body.classList.remove('dark');
            }
        });
    </script>
</head>

<body>
    <?php
    if (isset($message)) {
        foreach ($message as $msg) {
            echo '<div style="background-color: var(--dark); color: var(--light); padding: 10px; text-align: center;" class="message" onclick="this.remove();">' . $msg . '</div>';
        }
        unset($message);
    }
    ?>
    <?php
    $select_user = mysqli_query($conn, "SELECT * FROM `user` WHERE id = '$user_id'") or die('query failed');
    if (mysqli_num_rows($select_user) > 0) {
        $fetch_user = mysqli_fetch_assoc($select_user);
    }
    ;
    ?>
    <!-- Sidebar -->
    <div class="sidebar">
        <a href="index.php" class="logo">
            <svg viewBox="0 0 300 300" class="font">
                <!---->
                <defs data-v-fde0c5aa="">
                    <!---->
                </defs>


                <g data-v-fde0c5aa="" id="9455a294-f326-4286-948e-cfccc4a386d7" fill="#01D8FD"
                    transform="matrix(16.081870986272108,0,0,16.081870986272108,21.988304418690916,61.49098806547728)">
                    <path
                        d="M6.43 2.23L6.43 2.23L3.46 2.23C3.19 2.23 2.98 2.42 2.98 2.69L2.98 4.56C2.98 4.82 3.19 5.03 3.46 5.03L5.56 5.03C5.81 5.03 6.02 4.82 6.02 4.56C6.02 4.30 5.81 4.09 5.56 4.09L3.92 4.09L3.92 3.15L6.43 3.15C6.69 3.15 6.90 2.94 6.90 2.69C6.90 2.42 6.69 2.23 6.43 2.23ZM5.56 5.96L5.56 5.96L3.46 5.96C3.19 5.96 2.98 6.17 2.98 6.43L2.98 10.18C2.98 10.43 3.19 10.64 3.46 10.64C3.71 10.64 3.92 10.43 3.92 10.18L3.92 6.90L5.56 6.90C5.81 6.90 6.02 6.69 6.02 6.43C6.02 6.17 5.81 5.96 5.56 5.96ZM2.04 10.18L2.04 10.18L2.04 1.29L6.43 1.29C6.69 1.29 6.90 1.08 6.90 0.81C6.90 0.56 6.69 0.35 6.43 0.35L1.58 0.35C1.32 0.35 1.12 0.56 1.12 0.81L1.12 10.18C1.12 10.43 1.32 10.64 1.58 10.64C1.83 10.64 2.04 10.43 2.04 10.18ZM13.80 0.71L13.80 0.71C12.82 0.38 12.14 0.27 11.30 0.31C8.41 0.45 7.18 3.99 9.21 5.77C10.51 6.90 11.90 6.79 11.96 7.45C12.04 8.15 10.15 8.01 9.07 7.22C8.58 6.87 8.04 7.63 8.53 7.98C9.45 8.65 10.58 8.88 11.49 8.82C12.25 8.76 12.94 8.19 12.89 7.41C12.80 5.92 11.06 6.16 9.84 5.07C8.83 4.20 9.03 2.73 9.79 1.93C10.71 0.91 12.22 1.15 13.48 1.60C14.07 1.81 14.38 0.91 13.80 0.71ZM8.34 9.97L8.34 9.97C8.89 10.26 9.44 10.44 9.91 10.54C12.53 11.17 14.80 9.97 14.80 7.41C14.80 4.80 11.73 4.24 11.21 3.85C10.75 3.49 11.12 2.62 13.23 3.47C13.80 3.71 14.14 2.84 13.59 2.62C10.11 1.20 9.52 3.68 10.64 4.56C11.35 5.14 13.87 5.49 13.87 7.41C13.87 10.00 10.95 10.29 8.79 9.14C8.25 8.86 7.81 9.69 8.34 9.97ZM11.41 7.90L11.41 7.90L11.41 7.90L11.41 7.90Z">
                    </path>
                </g>
                <!----><!---->
            </svg>
            <div class="logo-name"><span>Flex</span>Store</div>
        </a>
        <ul class="side-menu">
            <li class="special"><a href="index.php"> <i class='bx bx-home-alt icon'></i>Home</a></li>
            <li class="special"><a href="shop.php"><i class="fa-solid fa-shop"></i>Shop</a></li>
            <li class="special"><a href="cart.php"><i class='bx bx-cart'></i>Cart</a></li>
            <li class="special"><a href="settings.php"><i class='bx bx-cog'></i>Settings</a></li>
            <li class="special"><a href="about.php"><i class='bx bx-info-circle'></i>About Us</a></li>
        </ul>

    </div>
    <!-- End of Sidebar -->

    <!-- Main Content -->
    <div class="content">
        <!-- Navbar -->
        <nav>
            <i class='bx bx-menu'></i>
            <form method="post" action="res.php">
                <div class="form-input">

                </div>
            </form>
            <div class="profile">
                <img class="user-pic" src="<?php echo htmlspecialchars($user['image']); ?>" onclick="toggleMenu()">
                <div class="sub-menu-wrap" id="subMenu">
                    <div class="sub-menu">
                        <div class="user-info">
                            <img src="<?php echo htmlspecialchars($user['image']); ?>">
                            <h2><?php echo htmlspecialchars($user['name']); ?></h2>
                        </div>
                        <hr>
                        <a href="index.php?logout=<?php echo $user_id; ?>"
                            onclick="return confirm('Are you sure you want to logout?');" class="sub-menu-link">
                            <i class='bx bx-log-out-circle'></i>
                            <p>Logout</p>
                        </a>
                    </div>
                </div>
            </div>
        </nav>

        <!-- End of Navbar -->

        <main>
            <div class="header">
                <div class="left">
                    <h1>Profile</h1>
                </div>
            </div>

            <form action="" class="profile-form" method="POST" enctype="multipart/form-data">
                <div class="form-item">
                    <label for="name">Name:</label>
                    <input type="text" name="name" value="<?php echo htmlspecialchars($user['name']); ?>" required>
                </div>

                <div class="form-item">
                    <label for="password">Password:</label>
                    <input type="password" name="password" placeholder="Enter new password" minlength="8">
                </div>

                <div class="form-item">
                    <label for="card_num">Card Number:</label>
                    <input type="text" name="card_num" value="<?php echo htmlspecialchars($user['card_num']); ?>"
                    maxlength="16" minlength="16" required>
                </div>

                <div class="form-item">
                    <label for="image">Profile Picture:</label>
                    <input type="file" name="image">
                </div>

                <img src="<?php echo htmlspecialchars($user['image']); ?>" alt="Profile Picture">

                <button type="submit">Update Profile</button>
            </form>



        </main>

    </div>





    <script>
        let subMenu = document.getElementById("subMenu");
        function toggleMenu() {
            if (subMenu.classList.contains("open-menu")) {
                subMenu.classList.remove("open-menu");
            } else {
                subMenu.classList.add("open-menu");
            }
        }

    </script>
    <script src="https://kit.fontawesome.com/5b9e84079b.js" crossorigin="anonymous"></script>
    <script src="index.js"></script>

</body>

</html>