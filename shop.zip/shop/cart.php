<?php
include 'config.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header('location:login-out/login-out.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$message = []; // Ensure $message is always an array

// Logout handling
if (isset($_GET['logout'])) {
    session_destroy();
    header('location:login-out/login-out.php');
    exit;
}

// Update cart quantity
if (isset($_POST['update_cart'])) {
    $update_quantity = intval($_POST['cart_quantity']);
    $update_id = intval($_POST['cart_id']);

    $stmt = $conn->prepare("UPDATE `cart` SET quantity = ? WHERE id = ?");
    $stmt->bind_param("ii", $update_quantity, $update_id);

    if ($stmt->execute()) {
        $message[] = 'Quantity updated successfully';
    } else {
        $message[] = 'Failed to update quantity';
    }
}

// Remove individual item from cart
if (isset($_GET['remove'])) {
    $remove_id = intval($_GET['remove']);

    $stmt = $conn->prepare("DELETE FROM `cart` WHERE id = ?");
    $stmt->bind_param("i", $remove_id);

    if ($stmt->execute()) {
        header('location:cart.php');
        exit;
    } else {
        $message[] = 'Failed to remove item';
    }
}

// Clear entire cart
if (isset($_GET['delete_all'])) {
    $stmt = $conn->prepare("DELETE FROM `cart` WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);

    if ($stmt->execute()) {
        header('location:cart.php');
        exit;
    } else {
        $message[] = 'Failed to clear cart';
    }
}

if (isset($_POST['buy'])) {
    // Retrieve form data
    $user_id = $_SESSION['user_id']; // Ensure user session is set
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $city = mysqli_real_escape_string($conn, $_POST['city']);
    $state = mysqli_real_escape_string($conn, $_POST['state']);
    $zip = mysqli_real_escape_string($conn, $_POST['zip']);
    $cardNumber = mysqli_real_escape_string($conn, $_POST['cardNumber']);
    $expiry = mysqli_real_escape_string($conn, $_POST['expiry']);
    $cvv = mysqli_real_escape_string($conn, $_POST['cvv']);

    // Validate user
    $select_user = mysqli_query($conn, "SELECT * FROM `user` WHERE id = '$user_id'") or die('Query failed');
    if (mysqli_num_rows($select_user) == 0) {
        die('User not found');
    }
    $fetch_user = mysqli_fetch_assoc($select_user);

    // Check cart contents
    $checkCartQuery = "SELECT COUNT(*) as count FROM cart WHERE user_id = '$user_id'";
    $result = mysqli_query($conn, $checkCartQuery);

    if ($result) {
        $row = mysqli_fetch_assoc($result);
        $cartItemCount = $row['count'];

        if ($cartItemCount == 0) {
            $message[] = 'Cart is empty'; // Use the message array to display feedback
        } else {
            // Check card details
            $ck_select = mysqli_query($conn, "SELECT * FROM `user` WHERE name = '$fetch_user[name]' AND card_num = '$cardNumber'") or die('Query failed');

            if (mysqli_num_rows($ck_select) > 0) {
                $message[] = 'Purchased Successfully!';

                // Clear cart after purchase
                $clearCartQuery = "DELETE FROM cart WHERE user_id = '$user_id'";
                mysqli_query($conn, $clearCartQuery) or die('Failed to clear cart');
            } else {
                $message[] = 'Wrong Data!';
            }
        }
    } else {
        $message[] = 'Error checking cart';
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/iconoir-icons/iconoir@main/css/iconoir.css" />
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/remixicon/3.5.0/remixicon.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <link rel="stylesheet" href="style.css">
    <style>
        .popup-container {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.7);
            z-index: 3;
            opacity: 0;
            transition: opacity 1s ease;

        }

        .popup-content {
            background: rgb(16, 199, 150);
            width: 400px;
            height: fit-content;
            margin: 100px auto;
            padding: 20px;
            border: 1px solid #000;
            border-radius: 5px;
            text-align: center;
            position: relative;
        }

        .close-popup {
            position: absolute;
            top: 10px;
            right: 10px;
            cursor: pointer;
            font-size: 20px;
        }
    </style>
    <title>Flex Store</title>
    <script>
        window.addEventListener('load', function () {
            const isDarkMode = localStorage.getItem('darkMode') === 'true';
            const body = document.body;

            if (isDarkMode) {
                body.classList.add('dark');
            } else {
                body.classList.remove('dark');
            }
        });
    </script>

</head>

<body>
    <?php
    if (isset($message)) {
        foreach ($message as $msg) {
            echo '<div style="background-color: var(--dark); color: var(--light); padding: 10px; text-align: center;" class="message" onclick="this.remove();">' . $msg . '</div>';
        }
        unset($message);
    }
    ?>

    <?php
    $select_user = mysqli_query($conn, "SELECT * FROM `user` WHERE id = '$user_id'") or die('query failed');
    if (mysqli_num_rows($select_user) > 0) {
        $fetch_user = mysqli_fetch_assoc($select_user);
    }
    ;
    ?>
    <!-- Sidebar -->
    <div class="sidebar">
        <a href="index.php" class="logo">
            <svg viewBox="0 0 300 300" class="font">
                <!---->
                <defs data-v-fde0c5aa="">
                    <!---->
                </defs>


                <g data-v-fde0c5aa="" id="9455a294-f326-4286-948e-cfccc4a386d7" fill="#01D8FD"
                    transform="matrix(16.081870986272108,0,0,16.081870986272108,21.988304418690916,61.49098806547728)">
                    <path
                        d="M6.43 2.23L6.43 2.23L3.46 2.23C3.19 2.23 2.98 2.42 2.98 2.69L2.98 4.56C2.98 4.82 3.19 5.03 3.46 5.03L5.56 5.03C5.81 5.03 6.02 4.82 6.02 4.56C6.02 4.30 5.81 4.09 5.56 4.09L3.92 4.09L3.92 3.15L6.43 3.15C6.69 3.15 6.90 2.94 6.90 2.69C6.90 2.42 6.69 2.23 6.43 2.23ZM5.56 5.96L5.56 5.96L3.46 5.96C3.19 5.96 2.98 6.17 2.98 6.43L2.98 10.18C2.98 10.43 3.19 10.64 3.46 10.64C3.71 10.64 3.92 10.43 3.92 10.18L3.92 6.90L5.56 6.90C5.81 6.90 6.02 6.69 6.02 6.43C6.02 6.17 5.81 5.96 5.56 5.96ZM2.04 10.18L2.04 10.18L2.04 1.29L6.43 1.29C6.69 1.29 6.90 1.08 6.90 0.81C6.90 0.56 6.69 0.35 6.43 0.35L1.58 0.35C1.32 0.35 1.12 0.56 1.12 0.81L1.12 10.18C1.12 10.43 1.32 10.64 1.58 10.64C1.83 10.64 2.04 10.43 2.04 10.18ZM13.80 0.71L13.80 0.71C12.82 0.38 12.14 0.27 11.30 0.31C8.41 0.45 7.18 3.99 9.21 5.77C10.51 6.90 11.90 6.79 11.96 7.45C12.04 8.15 10.15 8.01 9.07 7.22C8.58 6.87 8.04 7.63 8.53 7.98C9.45 8.65 10.58 8.88 11.49 8.82C12.25 8.76 12.94 8.19 12.89 7.41C12.80 5.92 11.06 6.16 9.84 5.07C8.83 4.20 9.03 2.73 9.79 1.93C10.71 0.91 12.22 1.15 13.48 1.60C14.07 1.81 14.38 0.91 13.80 0.71ZM8.34 9.97L8.34 9.97C8.89 10.26 9.44 10.44 9.91 10.54C12.53 11.17 14.80 9.97 14.80 7.41C14.80 4.80 11.73 4.24 11.21 3.85C10.75 3.49 11.12 2.62 13.23 3.47C13.80 3.71 14.14 2.84 13.59 2.62C10.11 1.20 9.52 3.68 10.64 4.56C11.35 5.14 13.87 5.49 13.87 7.41C13.87 10.00 10.95 10.29 8.79 9.14C8.25 8.86 7.81 9.69 8.34 9.97ZM11.41 7.90L11.41 7.90L11.41 7.90L11.41 7.90Z">
                    </path>
                </g>
                <!----><!---->
            </svg>
            <div class="logo-name"><span>Flex</span>Store</div>
        </a>
        <ul class="side-menu">
            <li class="special"><a href="index.php"> <i class='bx bx-home-alt icon'></i>Home</a></li>
            <li class="special"><a href="shop.php"><i class="fa-solid fa-shop"></i>Shop</a></li>
            <li class="special active"><a href="cart.php"><i class='bx bx-cart'></i>Cart</a></li>
            <li class="special"><a href="settings.php"><i class='bx bx-cog'></i>Settings</a></li>
            <li class="special"><a href="about.php"><i class='bx bx-info-circle'></i>About Us</a></li>
        </ul>

    </div>
    <!-- End of Sidebar -->

    <!-- Main Content -->
    <div class="content">
        <!-- Navbar -->
        <nav>
            <i class='bx bx-menu'></i>
            <form action="#">
                <div class="form-input">

                </div>
            </form>

            <div class="profile">
                <img class="user-pic" src="<?php echo $fetch_user['image']; ?>" onclick="toggleMenu()">
                <div class="sub-menu-wrap" id="subMenu">
                    <div class="sub-menu">
                        <div class="user-info">
                            <img src="<?php echo $fetch_user['image']; ?>">

                            <h2><?php echo $fetch_user['name']; ?></h2>
                        </div>
                        <hr>
                        <a class="sub-menu-link" href="profile.php?user_id=<?php echo $fetch_user['id']; ?>">
                            <i class='bx bx-user'></i>
                            <p>Profile</p>
                        </a>

                        <a href="index.php?logout=<?php echo $user_id; ?>"
                            onclick="return confirm('Are you sure you want to logout?');" class="sub-menu-link">
                            <i class='bx bx-log-out-circle'></i>
                            <p>logout</p>
                        </a>
                    </div>
                </div>
            </div>


        </nav>

        <!-- End of Navbar -->

        <main>
            <div class="header">
                <div class="left">
                    <h1>Cart</h1>
                    <ul class="breadcrumb">
                        <li><a href="index.php">
                                Shop
                            </a></li>
                        /
                        <li><a href="settings.php" class="active">Settings</a></li>
                    </ul>
                </div>

            </div>
            <!-- Insights -->
            <ul class="insights" style="grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));">
                <?php
                $cart_query = mysqli_query($conn, "SELECT * FROM `cart` WHERE user_id = '$user_id'") or die('query failed');
                $grand_total = 0;
                if (mysqli_num_rows($cart_query) > 0) {
                    while ($fetch_cart = mysqli_fetch_assoc($cart_query)) {
                        ?>


                        <li class="card">
                            <div>
                                <div class="img"><img src="<?php echo $fetch_cart['image']; ?>" height="75" alt=""></div>
                                <div class="head">
                                    <h1 class="title"><?php echo $fetch_cart['name']; ?></h1>
                                </div>
                                <div class="stars-button">
                                    <div class="price">
                                        <p class="salary"><?php echo $fetch_cart['price']; ?>$ </p>
                                        <form action="" method="post">
                                            <div class="quant"> <input type="hidden" name="cart_id"
                                                    value="<?php echo $fetch_cart['id']; ?>">

                                                Quantity : <input value="<?php echo $fetch_cart['quantity']; ?>" class="inp"
                                                    type="number" name="cart_quantity" min="1" max="999">
                                                <button type="submit" name="update_cart" class="option-btn"><i
                                                        class='bx bx-edit' style=""></i></button>
                                            </div><br>
                                            <?php $sub_total = ($fetch_cart['price'] * $fetch_cart['quantity']); ?>
                                            <a href="cart.php?remove=<?php echo $fetch_cart['id']; ?>" class="btn remove"
                                                onclick="return confirm('Are you sure to delete this product?');">Remove</a>
                                    </div>
                                </div>
                                </form>
                            </div>
                        </li>
                        <?php
                        $grand_total += $sub_total;
                    }
                } else {
                    echo '<li class="card" style="padding:20px; text-transform:capitalize;" colspan="6">Cart is empty</li>';
                }
                ?>
            </ul>

            <div class="center operations">
                <a href="index.php?delete_all" onclick="return confirm('Delete all the products from the cart?');"
                    class="delete-btn <?php echo ($grand_total > 1) ? '' : 'disabled'; ?>">Remove All</a>
                <button id="check" class="report buy">Checkout</button>
                <div class="total">
                    Total Price: $<?php echo $grand_total; ?></span>
                </div>
            </div>

        </main>

        <div id="popup" class="modal-overlay" style="display: none">
            <div class="checkout-form">
                <h2>Checkout</h2>
                <button id="close-popup" class="modal-close" onclick="closeModal()">&times;</button>
                <form id="checkout-form" method="POST" action="" onsubmit="handleSubmit(event)">
                    <input type="hidden" name="buy" value="1" />
                    <h3>Shipping Information</h3>
                    <input type="text" name="name" id="name" placeholder="Name" required />
                    <input type="text" name="address" id="address" placeholder="Address" required />
                    <input type="text" name="city" id="city" placeholder="City" required />
                    <input type="text" name="state" id="state" placeholder="State" required />
                    <input type="text" name="zip" id="zip" placeholder="Zip Code (optional)" />

                    <h3>Payment Information</h3>
                    <input type="text" name="cardNumber" id="cardNumber" placeholder="Card Number" maxlength="16"
                        minlength="16" required />
                    <input type="text" name="expiry" id="expiry" placeholder="Expiry Date (MM/YY)" maxlength="5"
                        required />
                    <input type="text" name="cvv" id="cvv" placeholder="CVV" maxlength="3" required />

                    <button type="submit" class="btn confirm">Confirm Order</button>
                </form>
            </div>
        </div>

    </div>

    <script>
        let subMenu = document.getElementById("subMenu");
        function toggleMenu() {
            if (subMenu.classList.contains("open-menu")) {
                subMenu.classList.remove("open-menu");
            } else {
                subMenu.classList.add("open-menu");
            }
        }

    </script>
    <script>

        const messages = document.querySelectorAll('.message');
        messages.forEach(message => {
            setTimeout(() => {
                message.remove();
            }, 2000);
        });
    </script>
    <script>

        document.addEventListener('DOMContentLoaded', function () {
            const showPopupLink = document.getElementById('check');
            const popupContainer = document.getElementById('popup');
            const closePopup = document.getElementById('close-popup');

            showPopupLink.addEventListener('click', function (e) {
                e.preventDefault();
                popupContainer.style.display = 'flex';
                // Trigger a reflow to enable the transition
                popupContainer.offsetHeight;
                popupContainer.style.opacity = 1;
            });

            closePopup.addEventListener('click', function () {
                popupContainer.style.opacity = 0;
                // Hide the popup after the transition is complete (1 second)
                setTimeout(function () {
                    popupContainer.style.display = 'none';
                }, 1000);
            });
        });

    </script>
    <script src="https://kit.fontawesome.com/5b9e84079b.js" crossorigin="anonymous"></script>
    <script src="index.js"></script>

</body>

</html>