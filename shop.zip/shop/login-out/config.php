<?php

$conn = mysqli_connect('localhost', 'root', '', 'shop');

// Check connection
if (!$conn) {
    die('Connection failed: ' . mysqli_connect_error());
}


?>