
<?php

include 'config.php';

if(isset($_POST['submit'])){

   $name = mysqli_real_escape_string($conn, $_POST['name']);
   $email = mysqli_real_escape_string($conn, $_POST['email']);
   $select = mysqli_query($conn, "SELECT * FROM `user` WHERE email = '$email' AND name = '$name'") or die('query failed');

   if(mysqli_num_rows($select) > 0){
    $res = mysqli_query($conn, "SELECT password FROM `user` WHERE email = '$email'") or die('query failed');
    if ($res && mysqli_num_rows($res) > 0) {
        $row = mysqli_fetch_assoc($res);
        $email = $row['password'];
        echo  '<div style=" background-color: white;position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        color: var(--light);
        padding: 10px;
        text-align: center;" class="message">'.'Your password is <span style="color:red;">'.$email.'</span> </div>';
    } 
   }else{
      $message[] = 'No Such user';
   }

}

?>







<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    
    <title>Sign In |Sign Up</title>
</head>

<body>
<?php
if(isset($message)){
   foreach($message as $message){
      echo '<div style=" background-color: white;position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      color: var(--light);
      padding: 10px;
      text-align: center;" class="message" onclick="this.remove();">'.$message.'</div>';
      
   }unset($message);
}
?>
    <div class="container" id="container">
        <div class="form-container reset">
            <form action="" method="post">
                <h1>Reset Password</h1>
                <br>
               <input type="text" name="name" placeholder="User Name" required>
               <input type="email" name="email" placeholder="Email" required>
                
                
                <a href="login-out.php">Sign In </a>
                <button type="submit" name="submit">Get password</button>
            </form>
        </div>
        
        
    </div>

    <script src="script.js"></script>
</body>

</html>