<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/iconoir-icons/iconoir@main/css/iconoir.css" />
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/remixicon/3.5.0/remixicon.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <link rel="stylesheet" href="style.css">

    <title>Flex Store</title>
    <script>
        window.addEventListener('load', function () {
            const isDarkMode = localStorage.getItem('darkMode') === 'true';
            const body = document.body;

            if (isDarkMode) {
                body.classList.add('dark');
            } else {
                body.classList.remove('dark');
            }
        });
    </script>
    <style>
        .main {
    width: 100%;
    max-width: 600px;
    margin: 2rem auto;
    padding: 2rem;
    background: #2c2f33; /* Dark gray background */
    border-radius: 10px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
    color: #ffffff; /* Text color */
    font-family: Arial, sans-serif;
}

form {
    display: flex;
    flex-direction: column;
}

label {
    margin-bottom: 0.5rem;
    font-weight: bold;
}

input[type="text"],
input[type="number"],
input[type="file"],
select {
    width: 100%;
    padding: 0.8rem;
    margin-bottom: 1rem;
    border: 1px solid #444;
    border-radius: 5px;
    background-color: #40444b;
    color: #ffffff;
    font-size: 1rem;
}

input:focus,
select:focus {
    border-color: #7289da; /* Light blue border on focus */
    outline: none;
    box-shadow: 0 0 5px rgba(114, 137, 218, 0.8);
}

button[type="submit"] {
    padding: 0.8rem 1.5rem;
    background-color: #7289da;
    border: none;
    border-radius: 5px;
    color: #ffffff;
    font-size: 1rem;
    font-weight: bold;
    cursor: pointer;
    transition: background-color 0.3s;
}

button[type="submit"]:hover {
    background-color: #5a73b5;
}

a.btn.remove {
    padding: 0.8rem 1.5rem;
    background-color: #ff5c5c;
    border: none;
    border-radius: 5px;
    color: #ffffff;
    font-size: 1rem;
    font-weight: bold;
    text-decoration: none;
    text-align: center;
    display: inline-block;
    transition: background-color 0.3s;
}

a.btn.remove:hover {
    background-color: #e24b4b;
}

img {
    margin-top: 1rem;
    border-radius: 5px;
    border: 1px solid #444;
}

@media (max-width: 768px) {
    .main {
        padding: 1.5rem;
    }

    input[type="text"],
    input[type="number"],
    input[type="file"],
    select {
        font-size: 0.9rem;
    }

    button[type="submit"],
    a.btn.remove {
        font-size: 0.9rem;
    }
}

    </style>
</head>

<body>

    <!-- Sidebar -->
    <div class="sidebar">
        <a href="index.php" class="logo">
            <svg viewBox="0 0 300 300" class="font">
                <!---->
                <defs data-v-fde0c5aa="">
                    <!---->
                </defs>


                <g data-v-fde0c5aa="" id="9455a294-f326-4286-948e-cfccc4a386d7" fill="#01D8FD"
                    transform="matrix(16.081870986272108,0,0,16.081870986272108,21.988304418690916,61.49098806547728)">
                    <path
                        d="M6.43 2.23L6.43 2.23L3.46 2.23C3.19 2.23 2.98 2.42 2.98 2.69L2.98 4.56C2.98 4.82 3.19 5.03 3.46 5.03L5.56 5.03C5.81 5.03 6.02 4.82 6.02 4.56C6.02 4.30 5.81 4.09 5.56 4.09L3.92 4.09L3.92 3.15L6.43 3.15C6.69 3.15 6.90 2.94 6.90 2.69C6.90 2.42 6.69 2.23 6.43 2.23ZM5.56 5.96L5.56 5.96L3.46 5.96C3.19 5.96 2.98 6.17 2.98 6.43L2.98 10.18C2.98 10.43 3.19 10.64 3.46 10.64C3.71 10.64 3.92 10.43 3.92 10.18L3.92 6.90L5.56 6.90C5.81 6.90 6.02 6.69 6.02 6.43C6.02 6.17 5.81 5.96 5.56 5.96ZM2.04 10.18L2.04 10.18L2.04 1.29L6.43 1.29C6.69 1.29 6.90 1.08 6.90 0.81C6.90 0.56 6.69 0.35 6.43 0.35L1.58 0.35C1.32 0.35 1.12 0.56 1.12 0.81L1.12 10.18C1.12 10.43 1.32 10.64 1.58 10.64C1.83 10.64 2.04 10.43 2.04 10.18ZM13.80 0.71L13.80 0.71C12.82 0.38 12.14 0.27 11.30 0.31C8.41 0.45 7.18 3.99 9.21 5.77C10.51 6.90 11.90 6.79 11.96 7.45C12.04 8.15 10.15 8.01 9.07 7.22C8.58 6.87 8.04 7.63 8.53 7.98C9.45 8.65 10.58 8.88 11.49 8.82C12.25 8.76 12.94 8.19 12.89 7.41C12.80 5.92 11.06 6.16 9.84 5.07C8.83 4.20 9.03 2.73 9.79 1.93C10.71 0.91 12.22 1.15 13.48 1.60C14.07 1.81 14.38 0.91 13.80 0.71ZM8.34 9.97L8.34 9.97C8.89 10.26 9.44 10.44 9.91 10.54C12.53 11.17 14.80 9.97 14.80 7.41C14.80 4.80 11.73 4.24 11.21 3.85C10.75 3.49 11.12 2.62 13.23 3.47C13.80 3.71 14.14 2.84 13.59 2.62C10.11 1.20 9.52 3.68 10.64 4.56C11.35 5.14 13.87 5.49 13.87 7.41C13.87 10.00 10.95 10.29 8.79 9.14C8.25 8.86 7.81 9.69 8.34 9.97ZM11.41 7.90L11.41 7.90L11.41 7.90L11.41 7.90Z">
                    </path>
                </g>
                <!----><!---->
            </svg>
            <div class="logo-name"><span>Flex</span>Store</div>
        </a>
        <ul class="side-menu">
            <li class="special"><a href="products.php"><i class="bx bxs-dashboard"></i>Products</a></li>
            <li class="special"><a href="add.php"><i class="bx bx-analyse"></i>Add New</a></li>
            <li class="special"><a href="about_admin.php"><i class='bx bx-info-circle'></i>About Us</a></li>
        </ul>

    </div>
    <!-- End of Sidebar -->

    <!-- Main Content -->
    <div class="content">
        <!-- Navbar -->
        <nav>
            <i class='bx bx-menu'></i>
        </nav>

        <!-- End of Navbar -->

        <main class="">
            <div style="justify-content: center !important;" class="header spc">
                <div class="left">
                    <h1>Edit A Product</h1>
                </div>
            </div>
            <?php
            include('config.php');

            // Get product ID from URL
            $ID = $_GET['id'];
            // Fetch product details from the database
            $up = mysqli_query($conn, "SELECT * FROM products WHERE id = $ID");
            $data = mysqli_fetch_array($up);
            ?>

            <center style="padding-bottom: 20px;">
                <div class="main">
                    <form action="up.php" method="post" enctype="multipart/form-data">
                        <label for="id">Product ID:</label>
                        <input type="text" name="id" style="color: #7a7a7a;" value="<?php echo $data['id']; ?>" readonly>


                        <label for="productName">Product Name:</label>
                        <input type="text" id="productName" name="name" value="<?php echo $data['name']; ?>"
                            required>

                        <label for="productDescription">Product Description:</label>
                        <input type="text" id="productDescription" name="description"
                            value="<?php echo $data['description']; ?>" required>

                        <label for="category">Category:</label>
                        <select id="category" name="category" required>
                            <option value="" disabled>Select a category</option>
                            <option value="camera" <?php echo $data['category'] === 'camera' ? 'selected' : ''; ?>>Camera
                            </option>
                            <option value="case" <?php echo $data['category'] === 'case' ? 'selected' : ''; ?>>Case
                            </option>
                            <option value="earbuds" <?php echo $data['category'] === 'earbuds' ? 'selected' : ''; ?>>
                                Earbuds</option>
                            <option value="headphones" <?php echo $data['category'] === 'headphones' ? 'selected' : ''; ?>>Headphones</option>
                            <option value="laptop" <?php echo $data['category'] === 'laptop' ? 'selected' : ''; ?>>Laptop
                            </option>
                            <option value="monitor" <?php echo $data['category'] === 'monitor' ? 'selected' : ''; ?>>
                                Monitor</option>
                            <option value="phone" <?php echo $data['category'] === 'phone' ? 'selected' : ''; ?>>Phone
                            </option>
                            <option value="speaker" <?php echo $data['category'] === 'speaker' ? 'selected' : ''; ?>>
                                Speaker</option>
                        </select>

                        <label for="brand">Brand:</label>
                        <select id="brand" name="brand" required>
                            <option value="" disabled>Select a brand</option>
                            <option value="generic" <?php echo $data['brand'] === 'generic' ? 'selected' : ''; ?>>Generic
                            </option>
                            <option value="acer" <?php echo $data['brand'] === 'acer' ? 'selected' : ''; ?>>Acer</option>
                            <option value="anker" <?php echo $data['brand'] === 'anker' ? 'selected' : ''; ?>>Anker
                            </option>
                            <option value="apple" <?php echo $data['brand'] === 'apple' ? 'selected' : ''; ?>>Apple
                            </option>
                            <option value="asus" <?php echo $data['brand'] === 'asus' ? 'selected' : ''; ?>>ASUS</option>
                            <option value="bengoo" <?php echo $data['brand'] === 'bengoo' ? 'selected' : ''; ?>>BENGOO
                            </option>
                            <option value="canon" <?php echo $data['brand'] === 'canon' ? 'selected' : ''; ?>>Canon
                            </option>
                            <option value="coolermaster" <?php echo $data['brand'] === 'coolermaster' ? 'selected' : ''; ?>>Cooler Master</option>
                            <option value="corsair" <?php echo $data['brand'] === 'corsair' ? 'selected' : ''; ?>>CORSAIR
                            </option>
                            <option value="dell" <?php echo $data['brand'] === 'dell' ? 'selected' : ''; ?>>Dell</option>
                            <option value="honor" <?php echo $data['brand'] === 'honor' ? 'selected' : ''; ?>>HONOR
                            </option>
                            <option value="hp" <?php echo $data['brand'] === 'hp' ? 'selected' : ''; ?>>HP</option>
                            <option value="huawei" <?php echo $data['brand'] === 'huawei' ? 'selected' : ''; ?>>HUAWEI
                            </option>
                            <option value="hyperx" <?php echo $data['brand'] === 'hyperx' ? 'selected' : ''; ?>>HyperX
                            </option>
                            <option value="infinix" <?php echo $data['brand'] === 'infinix' ? 'selected' : ''; ?>>Infinix
                            </option>
                            <option value="lenovo" <?php echo $data['brand'] === 'lenovo' ? 'selected' : ''; ?>>Lenovo
                            </option>
                            <option value="lg" <?php echo $data['brand'] === 'lg' ? 'selected' : ''; ?>>LG</option>
                            <option value="logitech" <?php echo $data['brand'] === 'logitech' ? 'selected' : ''; ?>>
                                Logitech</option>
                            <option value="masrgaming" <?php echo $data['brand'] === 'masrgaming' ? 'selected' : ''; ?>>
                                MASRGAMING</option>
                            <option value="msi" <?php echo $data['brand'] === 'msi' ? 'selected' : ''; ?>>MSI</option>
                            <option value="nikon" <?php echo $data['brand'] === 'nikon' ? 'selected' : ''; ?>>Nikon
                            </option>
                            <option value="nokia" <?php echo $data['brand'] === 'nokia' ? 'selected' : ''; ?>>Nokia
                            </option>
                            <option value="oppo" <?php echo $data['brand'] === 'oppo' ? 'selected' : ''; ?>>OPPO</option>
                            <option value="oraimo" <?php echo $data['brand'] === 'oraimo' ? 'selected' : ''; ?>>Oraimo
                            </option>
                            <option value="razer" <?php echo $data['brand'] === 'razer' ? 'selected' : ''; ?>>Razer
                            </option>
                            <option value="realme" <?php echo $data['brand'] === 'realme' ? 'selected' : ''; ?>>Realme
                            </option>
                            <option value="redragon" <?php echo $data['brand'] === 'redragon' ? 'selected' : ''; ?>>
                                Redragon</option>
                            <option value="samsung" <?php echo $data['brand'] === 'samsung' ? 'selected' : ''; ?>>Samsung
                            </option>
                            <option value="sony" <?php echo $data['brand'] === 'sony' ? 'selected' : ''; ?>>Sony</option>
                            <option value="xiaomi" <?php echo $data['brand'] === 'xiaomi' ? 'selected' : ''; ?>>Xiaomi
                            </option>
                        </select>

                        <label for="productPrice">Product Price:</label>
                        <input type="number" id="productPrice" name="price" value="<?php echo $data['price']; ?>"
                            min="0" step="0.01" required>

                        <label for="productImage">Product Image:</label>
                        <input type="file" id="productImage" name="image" accept="image/*">
                        <img src="<?php echo $data['image']; ?>" alt="Product Image" width="100"><br>
                        <button type="submit" name="update">Update Product</button><br>
                        <a href="products.php" class="btn remove" style="display: inline-block;">Cancel</a>
                    </form>
                </div>
            </center>

        </main>

    </div>

    <script src="index.js"></script>

</body>

</html>