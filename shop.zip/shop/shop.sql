-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 18, 2024 at 11:37 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `user_id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` double NOT NULL,
  `image` varchar(150) NOT NULL,
  `quantity` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `user_id`, `name`, `price`, `image`, `quantity`) VALUES
(38, 0, 'SAMSUNG 32-Inch M7 (M70D) Series', 399.99, 'images/Products/monitor/samsung/SAMSUNG 32-Inch M7 (M70D) Series.jpg', 1),
(80, 1, 'iPhone 16 Pro Max', 1170, 'images/Products/phone/apple/iPhone 16 Pro Max.jpg', 3),
(81, 1, 'HUAWEI AM08 Little Swan Wireless Bluetooth Speaker', 21.98, 'images/Products/speaker/huawei/HUAWEI AM08 Little Swan Wireless Bluetooth Speaker.jpg', 1),
(82, 3, 'Logitech Zone Vibe 100 Lightweight Wireless', 129.8, 'images/Products/headphones/logitech/Logitech Zone Vibe 100 Lightweight Wireless.jpg', 3),
(84, 5, 'LG 27GP750-B 27” Ultragear', 299.99, 'images/Products/monitor/lg/LG 27GP750-B Ultragear.jpg', 1),
(85, 1, 'P9/A9 Wireless Bluetooth Headphones', 4.98, 'images/Products/headphones/generic/P9-A9 Wireless Bluetooth Headphones.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` varchar(100) NOT NULL,
  `image` varchar(150) NOT NULL,
  `category` varchar(100) DEFAULT NULL,
  `brand` varchar(100) DEFAULT NULL,
  `description` varchar(3000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `price`, `image`, `category`, `brand`, `description`) VALUES
(1, 'DELL G15 5530 Gaming', '989.98', 'images/Products/laptop/dell/DELL G15 5530 Gaming.jpg', 'laptop', 'dell', 'DELL G15 5530 Gaming Laptop - 13th Intel Core i7-13650HX 14 Cores, NVIDIA GeForce RTX 3050 6GB GDDR6 Graphics, 16GB DDR5-4800 MHz RAM, 512GB SSD, 15.6\" FHD (1920x1080) 120Hz, 4Z RGB Backlit, Ubuntu'),
(2, 'Anker Soundcore R50i Black True Wireless (TWS)', '16.70', 'images/Products/earbuds/anker/Soundcore a3991h11 by anker life p2i true wireless.jpg', 'earbuds', 'anker', 'Anker Soundcore R50i Black True Wireless (TWS) Earbuds 10mm Drivers with Big Bass, Bluetooth 5.3, 30H Playtime, IPX5-Water Resistant, AI Clear Calls with 2 Mics, 22 Preset EQs via App'),
(3, 'Canon EOS R100 Mirrorless', '499.00', 'images/Products/camera/canon/Canon EOS R100 Mirrorless.jpg', 'camera', 'canon', 'Canon EOS R100 Mirrorless Camera RF-S18-45mm F4.5-6.3 is STM & RF-S55-210mm F5-7.1 is STM Lens Kit, 24.1 Megapixel CMOS (APS-C) Sensor, 4K Video, RF Mount, Black'),
(4, 'Canon EOS Rebel T7 DSLR', '479.00', 'images/Products/camera/canon/Canon EOS Rebel T7 DSLR.jpg', 'camera', 'canon', 'Canon EOS Rebel T7 DSLR Camera with 18-55mm Lens | Built-in Wi-Fi | 24.1 MP CMOS Sensor | DIGIC 4+ Image Processor and Full HD Videos'),
(5, 'Canon EOS R5 Mirrorless', '3899.00', 'images/Products/camera/canon/Canon EOS R5 Mirrorless.jpg', 'camera', 'canon', 'Canon EOS R5 Mirrorless Camera (Body Only), Full-Frame Hybrid Camera, 8K Video, 45 Megapixel CMOS Sensor, DIGIC X Image Processor, Up to 12 FPS, RF Mount, Black'),
(6, 'CORSAIR 3500X', '109.99', 'images/Products/case/corsair/CORSAIR 3500X.jpg', 'case', 'corsair', 'CORSAIR 3500X ARGB Mid-Tower ATX PC Case – Panoramic Tempered Glass – Reverse Connection Motherboard Compatible – 3X CORSAIR RS120 ARGB Fans Included – White'),
(7, 'Corsair 5000X', '214.99', 'images/Products/case/corsair/Corsair 5000X.jpg', 'case', 'corsair', 'Corsair 5000X RGB QL Edition Mid-Tower Case - True White (Four QL120 RGB Fans, Included Lighting Node CORE, Easy Cable Management, 136 Total LEDs) White'),
(8, 'Razer BlackShark V2 X Gaming', '69.98', 'images/Products/headphones/razer/Razer BlackShark V2 X Gaming.jpg', 'headphones', 'razer', 'Razer BlackShark V2 X Gaming Headset: 7.1 Surround Sound - 50mm Drivers - Memory Foam Cushion - for PC, Mac, PS4, PS5, Switch, Xbox One, Xbox Series X|S, Mobile - 3.5mm Audio Jack - White'),
(9, 'G5 Odyssey', '329.99', 'images/Products/monitor/samsung/G5 Odyssey .jpg', 'monitor', 'samsung', 'SAMSUNG 32-Inch Odyssey G55C Series QHD 1000R Curved Gaming Monitor'),
(10, 'iPhone 16 Pro Max', '1170.00', 'images/Products/phone/apple/iPhone 16 Pro Max.jpg', 'phone', 'apple', 'Apple iPhone 16 Pro Max (256 GB) - Black Titanium'),
(11, 'CORSAIR 3500X', '109.99', 'images/Products/case/corsair/CORSAIR 3500X.jpg', 'case', 'corsair', 'CORSAIR 3500X ARGB Mid-Tower ATX PC Case – Panoramic Tempered Glass – Reverse Connection Motherboard Compatible – 3X CORSAIR RS120 ARGB Fans Included – White'),
(12, 'Lenovo Legion 5 15ACH6', '779.98', 'images/Products/laptop/lenovo/Lenovo Legion 5 15ACH6 Gaming.jpg', 'laptop', 'lenovo', 'Lenovo Legion 5 15ACH6 Gaming Laptop - Ryzen 5-5600H, 16 GB RAM, 512 GB SSD, NVIDIA GeForce RTX 3050 Ti 4GB GDDR6 Graphics, 15.6\" FHD (1920x1080) IPS 120Hz, Backlit Keyboard, WIN 11'),
(13, 'HUAWEI AM08 Little Swan Wireless Bluetooth Speaker', '21.98', 'images/Products/speaker/huawei/HUAWEI AM08 Little Swan Wireless Bluetooth Speaker.jpg', 'speaker', 'huawei', 'HUAWEI AM08 Little Swan Wireless Bluetooth Speaker Touch Control, Gold'),
(14, 'Acer Nitro 5', '1136.00', 'images/Products/laptop/acer/Acer Nitro 5.jpg', 'laptop', 'acer', 'Acer Nitro 5 AN515-55-53E5 Gaming Laptop | Intel Core i5-10300H | NVIDIA GeForce RTX 3050 Laptop GPU | 15.6\" FHD 144Hz IPS Display | 8GB DDR4 | 256GB NVMe SSD | Intel Wi-Fi 6 | Backlit Keyboard'),
(15, 'Samsung Galaxy S24 Ultra', '898.80', 'images/Products/phone/samsung/Samsung Galaxy S24 Ultra.jpg', 'phone', 'samsung', 'Samsung Galaxy S24 Ultra, AI Phone, 256GB Storage, Titanium Gray, 12GB RAM, Android Smartphone, 200MP Camera, S Pen, Long Battery Life'),
(16, 'Xiaomi Redmi 13C', '118.78', 'images/Products/phone/xiaomi/Xiaomi Redmi 13C.jpg', 'phone', 'xiaomi', 'Xiaomi Redmi 13C (Stardust Black, 6GB RAM, 128GB Storage) | 90Hz Display | 50MP AI Triple Camera'),
(17, 'Nikon D7500 20.9MP DSLR', '1499.95', 'images/Products/camera/nikon/Nikon D7500 20.9MP DSLR.jpg', 'camera', 'nikon', 'Nikon D7500 20.9MP DSLR Camera with AF-S DX NIKKOR 18-140mm f/3.5-5.6G ED VR Lens, Black'),
(18, 'COOLPIX P950', '796.95', 'images/Products/camera/nikon/Nikon COOLPIX P950.jpg', 'camera', 'nikon', 'Nikon COOLPIX P950 - Black'),
(19, 'Sony ZV-1F Vlog', '499.99', 'images/Products/camera/sony/Sony ZV-1F Vlog.jpg', 'camera', 'sony', 'Sony ZV-1F Vlog Camera for Content Creators and Vloggers Black'),
(20, 'Sony Alpha A6100 Mirrorless', '1099.99', 'images/Products/camera/sony/Sony Alpha A6100 Mirrorless.jpg', 'camera', 'sony', 'Sony Alpha A6100 Mirrorless Camera with 16-50mm and 55-210mm Zoom Lenses, ILCE6100Y/B, Black'),
(21, 'Cooler Master HAF 700 EVO E-ATX High Airflow', '39.99', 'images/Products/case/cooler master/Cooler Master HAF 700 EVO E-ATX High Airflow.jpg', 'case', 'coolermaster', 'Cooler Master HAF 700 EVO E-ATX High Airflow PC Case, IRIS Customizable LCD .Breathable TG Front Panel, 200mm Sickleflow Fans, 1 x USB 3.2 gen 2 Type C, 4 x USB 3.2 gen 1 (3.0) (H700E-IGNN-S00)'),
(22, 'Cooler Master MasterBox Q300L Micro-ATX Tower', '599.99', 'images/Products/case/cooler master/Cooler Master MasterBox Q300L Micro-ATX Tower.jpg', 'case', 'coolermaster', 'Cooler Master MasterBox Q300L Micro-ATX Tower with Magnetic Design Dust Filter, Transparent Acrylic Side Panel, Adjustable I/O & Fully Ventilated Airflow, Black (MCB-Q300L-KANN-S00)'),
(23, 'CORSAIR iCUE LINK 6500X', '269.99', 'images/Products/case/corsair/CORSAIR iCUE LINK 6500X.jpg', 'case', 'corsair', 'CORSAIR iCUE LINK 6500X RGB Mid-Tower ATX Dual Chamber PC Case – Panoramic Tempered Glass - Reverse Connection Motherboard Compatible – 3x CORSAIR RX120 RGB Fans Included – Black'),
(24, 'MSI MAG Forge 321R Airflow', '79.99', 'images/Products/case/msi/MSI MAG Forge 321R Airflow.jpg', 'case', 'msi', 'MSI MAG Forge 321R Airflow - Premium Mid-Tower Gaming PC Case - Tempered Glass Side Panel - ARGB 120mm Fans - Liquid Cooling Support up to 360mm Radiator - Vented Front Panel'),
(25, 'MSI MAG PANO 100L PZ White', '79.99', 'images/Products/case/msi/MSI MAG PANO 100L PZ White.jpg', 'case', 'msi', 'MSI MAG PANO 100L PZ White - Premium Mid-Tower Gaming PC Case - Tempered Glass Side Panel - Liquid Cooling Support up to 360mm Radiator - White Color Case'),
(26, 'MSI Mid-Tower', '79.99', 'images/Products/case/msi/MSI Mid-Tower.jpg', 'case', 'msi', 'MSI Mid-Tower PC Gaming Case – Tempered Glass Side Panel – 1 x 120mm aRGB Fan –1 x 120mm Fan – Liquid Cooling Support up to 240mm Radiator x 1 – MAG Vampiric 100R'),
(27, 'MSI MPG GUNGNIR 300R Airflow White', '179.00', 'images/Products/case/msi/MSI MPG GUNGNIR 300R Airflow White.jpg', 'case', 'msi', 'MSI MPG GUNGNIR 300R Airflow White - Premium Mid-Tower Gaming PC Case - Tempered Glass Side Panel - ARGB 120mm Fans - Liquid Cooling Support up to 360mm Radiator - White Color Case'),
(28, 'MSI MAG Forge 100M Mid Tower', '135.00', 'images/Products/case/msi/MSI MAG Forge 100M Mid Tower.jpg', 'case', 'msi', 'MSI MAG Forge 100M Mid Tower Gaming Computer Case Black, 2X 120 mm RGB PWM Fan, 1x 120 mm Fan, 1-6 RGB Hub, Tempered Glass Panel, ATX, mATX, Mini-ITX - 306-7G03M11-809'),
(29, 'Soundcore a3991h11 by anker life p2i true wireless', '23.88', 'images/Products/earbuds/anker/Soundcore a3991h11 by anker life p2i true wireless.jpg', 'earbuds', 'anker', 'Soundcore a3991h11 by anker life p2i true wireless earbuds, ai-enhanced calls, 10mm drivers, 2 eq modes, 28h playtime with fast charging, bluetooth 5.2, lightweight and secure fit, button control'),
(30, 'Apple AirPods 4 ANC Wireless', '223.00', 'images/Products/earbuds/apple/Apple AirPods 4 ANC Wireless.jpg', 'earbuds', 'apple', 'Apple AirPods 4 ANC Wireless Earbuds, Bluetooth Headphones, Active Noise Cancellation, Adaptive Audio, Transparency Mode, Personalized Spatial Audio, USB-C Charging Case, Wireless Charging, H2 Chip'),
(31, 'HUAWEI FreeBuds 5i Wireless', '55.20', 'images/Products/earbuds/huawei/HUAWEI FreeBuds 5i Wireless.jpg', 'earbuds', 'huawei', 'HUAWEI FreeBuds 5i Wireless Earbuds - Noise Cancelling Earphones with Long Lasting Battery Life - Bluetooth and Water Resistant in-Ear Headphones with Hi-Res Sound Certified - Blue'),
(32, 'Xiaomi Redmi Buds 4 Lite', '14.50', 'images/Products/earbuds/xiaomi/Xiaomi Redmi Buds 4 Lite.jpg', 'earbuds', 'xiaomi', 'Xiaomi Redmi Buds 4 Lite: 12mm Dynamic Driver, HD Sound, IPX4 Water-Resistant, Bluetooth 5.2, 18.5Hr Battery, Google Fast Pair | AI Call Noise Reduction | Touch Controls |Gray | 6 Month Local warranty'),
(33, 'Anker Soundcore H30i Wireless', '31.00', 'images/Products/headphones/anker/Anker Soundcore H30i Wireless.jpg', 'headphones', 'anker', 'Anker Soundcore H30i Wireless On-Ear Headphones, Foldable Design, Pure Bass, 70H Playtime, Bluetooth 5.3, Lightweight and Comfortable, App Connectivity, Multipoint Connection (Black)'),
(34, 'soundcore by Anker Q20i Hybrid', '37.92', 'images/Products/headphones/anker/soundcore by Anker Q20i Hybrid.jpg', 'headphones', 'anker', 'soundcore by Anker Q20i Hybrid Active Noise Cancelling Headphones, Wireless Over-Ear Bluetooth, 40H Long ANC Playtime, Hi-Res Audio, Big Bass, Customize via an App, Transparency Mode, Ideal for Travel'),
(35, 'Bengoo V-4', '10.98', 'images/Products/headphones/bengoo/Bengoo V-4.jpg', 'headphones', 'bengoo', 'Bengoo V-4 Gaming Headset for Xbox One, PS4, PC, Controller, Noise Cancelling Over Ear Headphones with Mic, LED Light Bass Surround Soft Memory Earmuffs for PS2 Mac'),
(36, 'HyperX 683L9AA Medium Cloud', '49.58', 'images/Products/headphones/hyperx/HyperX 683L9AA Medium Cloud.jpg', 'headphones', 'hyperx', 'HyperX 683L9AA Medium Cloud Stinger 2 Core DTS Headphone X Spatial Audio Gaming Headset, Medium, Wired Black'),
(37, 'HyperX Cloud III', '114.44', 'images/Products/headphones/hyperx/HyperX Cloud III.jpg', 'headphones', 'hyperx', 'HyperX Cloud III – Wired Gaming Headset, PC, PS5, Xbox Series X|S, Angled 53mm Drivers, DTS, Memory Foam, Durable Frame, Ultra-Clear 10mm Mic, USB-C, USB-A, 3.5mm – Black/Red Headphones Headset'),
(38, 'HyperX Cloud Alpha', '141.80', 'images/Products/headphones/hyperx/HyperX Cloud Alpha.jpg', 'headphones', 'hyperx', 'HyperX Cloud Alpha – Gaming Headset with In-line volume control'),
(39, 'Logitech Zone 300 Wireless', '95.80', 'images/Products/headphones/logitech/Logitech Zone 300 Wireless.jpg', 'headphones', 'logitech', 'Logitech Zone 300 Wireless Bluetooth Headset With Noise-Cancelling Microphone, Compatible with Windows, Mac, Chrome, Linux, iOS, iPadOS, Android – Black'),
(40, 'Logitech Zone Vibe 100 Lightweight Wireless', '129.80', 'images/Products/headphones/logitech/Logitech Zone Vibe 100 Lightweight Wireless.jpg', 'headphones', 'logitech', 'Logitech Zone Vibe 100 Lightweight Wireless Over-Ear Headphones with Noise-Cancelling Microphone, Advanced Multipoint Bluetooth Headset, Works with Teams, Google Meet, Zoom, Mac/PC - Grey'),
(41, 'Razer kraken gaming', '78.00', 'images/Products/headphones/razer/Razer kraken gaming.jpg', 'headphones', 'razer', 'Razer kraken gaming headset 2019: lightweight aluminum frame - retractable noise cancelling mic - for pc, xbox, ps4, nintendo switch - mercury white'),
(42, 'Redragon Hylas RGB Wired', '19.78', 'images/Products/headphones/redragon/Redragon Hylas RGB Wired.jpg', 'headphones', 'redragon', 'Redragon Hylas RGB Wired Gaming Headset with Microphone (H260, White)'),
(43, 'Redragon h510 zeus wired', '41.98', 'images/Products/headphones/redragon/Redragon h510 zeus wired.jpg', 'headphones', 'redragon', 'Redragon h510 zeus wired gaming headset - 7.1 surround sound - memory foam ear pads - 53mm drivers - detachable microphone - multi platforms headphone - works with pc, ps4/3 & xbox one/series x, ns'),
(44, 'Redragon H270 RGB', '13.72', 'images/Products/headphones/redragon/Redragon H270 RGB.jpg', 'headphones', 'redragon', 'Redragon H270 RGB Gaming Headset with Microphone Wired Compatible with Xbox One, Nintendo Switch, PS4, PS5, PC and Laptops (White)'),
(45, 'Redragon HEADSET GAMER PARIS H390-RGB', '30.98', 'images/Products/headphones/redragon/Redragon HEADSET GAMER PARIS H390-RGB.jpg', 'headphones', 'redragon', 'Redragon HEADSET GAMER PARIS H390-RGB USB BLACK'),
(46, 'edragon h350 rgb wired', '36.66', 'images/Products/headphones/redragon/Redragon h350 rgb wired.jpg', 'headphones', 'redragon', 'Redragon h350 rgb wired gaming headphones, dynamic rgb backlight - stereo surround audio - 50mm driver - removable microphone, overear headphones for pc/ps4/xbox one/ns'),
(47, 'Sony WH-CH520 Wireless', '51.18', 'images/Products/headphones/sony/Sony WH-CH520 Wireless.jpg', 'headphones', 'sony', 'Sony WH-CH520 Wireless Bluetooth On-Ear with Mic for Phone Call, Black'),
(48, 'Acer Aspire 3', '389.90', 'images/Products/laptop/acer/Acer Aspire 3.jpg', 'laptop', 'acer', 'Acer Aspire 3 A315-58 15.6-Inch Laptop - (Intel Core i3-1115G4, 8GB, 256GB SSD, Full HD Display, Windows 11, Silver)'),
(49, 'Wireless Bluetooth Headphone RGB headset', '7.16', 'images/Products/headphones/generic/Wireless Bluetooth Headphone RGB headset.jpg', 'headphones', 'generic', 'Wireless Bluetooth Headphone RGB headset With Mic LED Light Big Headsets Game Helmet Stereo Music Earphone For Cell Phone Laptop FM V5.2 with External Microphone and Support SD Card (BLACK)'),
(50, 'P9/A9 Wireless Bluetooth Headphones', '4.98', 'images/Products/headphones/generic/P9-A9 Wireless Bluetooth Headphones.jpg', 'headphones', 'generic', 'P9/A9 Wireless Bluetooth Headphones Over Ear Stereo Music Headphones Gaming Headset - Supports Mircoro TF for Laptop/Mobile Phone/PC (BLACK)'),
(51, 'Apple MacBook Pro', '3808.12', 'images/Products/laptop/apple/Apple MacBook Pro.jpg', 'laptop', 'apple', 'Apple MacBook Pro 16\" M3 Pro/12C CPU/18C GPU/36GB/512SSD/Space Black'),
(52, 'Apple MacBook Air', '1039.00', 'images/Products/laptop/apple/Apple MacBook Air.jpg', 'laptop', 'apple', '2022 Apple MacBook Air laptop with M2 chip: 13.6-inch Liquid Retina display, 8GB RAM, 256GB SSD storage, 1080p FaceTime HD camera. Works with iPhone and iPad; Midnight; English'),
(53, 'ASUS TUF Gaming A15', '659.98', 'images/Products/laptop/asus/ASUS TUF Gaming A15.jpg', 'laptop', 'asus', 'ASUS TUF Gaming A15, AMD Ryzen 5 7535HS, 4GB GDDR6 NVIDIA GeForce RTX 3050, 8GB RAM, 15.6\" (1920 x 1080) 16:10 144HZ, 512GB SSD, Windows 11 (FA506NC-HN005W) 1 Year Perfect Warranty by ASUS, Black'),
(54, 'Dell Vostro 3520', '395.98', 'images/Products/laptop/dell/Dell Vostro 3520.jpg', 'laptop', 'dell', 'Dell Vostro 3520 Laptop - 12th Intel Core i5-1235U 10-Cores, 8GB RAM, 512GB SSD, Intel UHD Graphics, 15.6\" FHD (1920 x 1080) 120Hz 250 nits Anti-Glare, FingerPrint, Ubuntu - Carbon Black'),
(55, 'Dell Inspiron 3520', '337.76', 'images/Products/laptop/dell/Dell Inspiron 3520.jpg', 'laptop', 'dell', 'Dell Inspiron 3520 Laptop - 12th Intel Core i3-1215U 6-Cores, 8GB RAM, 256GB SSD, Intel UHD Graphics, 15.6\" FHD (1920 x 1080) 120Hz 250 nits Anti-Glare, Windows 11 - Carbon Black'),
(56, 'HP Pavilion X360 2-in-1', '619.98', 'images/Products/laptop/hp/HP Pavilion X360 2-in-1.jpg', 'laptop', 'hp', 'HP Pavilion X360 2-in-1 Laptop (14-EK0011NE), Intel Core i5 1235U, 12th Generation, 8GB DDR4 3200, 512GB SSD - Silver'),
(57, 'HP Probook 650 G5 Business', '440.00', 'images/Products/laptop/hp/HP Probook 650 G5 Business.jpg', 'laptop', 'hp', 'HP Probook 650 G5 Business Laptop with Backlit Keyboard, 15.6in FHD(1920x1080), Intel Core i5-8365U up to 4.1GHz, 16GB RAM, 512GB SSD, Win 10pro(Renewed)'),
(58, 'HP EliteBook 840 G4 Business', '333.00', 'images/Products/laptop/hp/HP EliteBook 840 G4 Business.jpg', 'laptop', 'hp', 'HP EliteBook 840 G4 Business Laptop - Intel Core i5-7300U, 8GB, 256GB SSD PCIe, 14 Full HD, Eng Keyboard, Windows 10 Pro, Silver'),
(59, 'HP Victus 15-fb0049ne Gaming', '549.98', 'images/Products/laptop/hp/HP Victus 15-fb0049ne Gaming.jpg', 'laptop', 'hp', 'HP Victus 15-fb0049ne Gaming Laptop - Ryzen 5-5600H 6-Cores, 8 GB RAM, 512GB SSD, 15.6\" FHD (1920X1080) 144 Hz IPS, AMD Radeon RX 6500M 4GB GDDR6 Graphics, Backlit Keyboard - Mica Silver'),
(60, 'HP Laptop 15-fd0054ne', '499.98', 'images/Products/laptop/hp/HP Laptop 15-fd0054ne.jpg', 'laptop', 'hp', 'HP Laptop 15-fd0054ne - Intel Core i5-1334U 13th Generation, 8GB RAM, 512GB SSD, Integrated Intel Iris Xe Graphics, 15.6\" FHD (1920x1080) anti-glare 250nits, backlit, DOS - natural silver'),
(61, 'Lenovo IdeaPad Flex 5 2n1', '605.78', 'images/Products/laptop/lenovo/Lenovo IdeaPad Flex 5 2n1.jpg', 'laptop', 'lenovo', 'Lenovo IdeaPad Flex 5 2n1 Laptop - Intel Core i5-1135G7, 8GB RAM, 256GB SSD, Intel Iris Xe Graphics, 14\" FHD (1920x1080) IPS 250nits 10-point Multi-touch, FingerPrint, Windows 11 + Lenovo Digital Pen'),
(62, 'Lenovo IdeaPad Slim 3 15IRH8', '659.98', 'images/Products/laptop/lenovo/Lenovo IdeaPad Slim 3 15IRH8.jpg', 'laptop', 'lenovo', 'Lenovo IdeaPad Slim 3 15IRH8 Laptop - 13th Intel Core i7-13620H, 16 GB DDR5-4800 MHz, 512 GB SSD, Integrated Intel UHD Graphics, 15.6\" FHD (1920x1080) 250nits Anti-glare, Dos //BAG//2 Years Warranty'),
(63, 'Lenovo Ideapad 1 15IGL7', '252.16', 'images/Products/laptop/lenovo/Lenovo Ideapad 1 15IGL7.jpg', 'laptop', 'lenovo', 'Lenovo Ideapad 1 15IGL7 Laptop - Intel Celeron N4020-8GB - 256GB SSD - Intel UHD Integrated Graphics - 15.6\" FHD - Blue'),
(64, 'Lenovo IdeaPad Gaming 3 15ARH7', '873.32', 'images/Products/laptop/lenovo/Lenovo IdeaPad Gaming 3 15ARH7.jpg', 'laptop', 'lenovo', 'Lenovo IdeaPad Gaming 3 15ARH7 - Ryzen 7 7735HS, NVIDIA GeForce RTX 4050 6GB GDDR6 Graphics,16GB DDR5-4800 RAM, 512GB SSD, 15.6\" FHD (1920x1080) IPS 250nits 120Hz, Backlit Keyboard-2 Years'),
(65, 'MSI Raider GE68HX Gaming', '1391.70', 'images/Products/laptop/msi/MSI Raider GE68HX Gaming.jpg', 'laptop', 'msi', 'MSI Raider GE68HX Gaming Laptop | 16\"\" FHD+ IPS 144Hz | Intel 24-core i9-13950HX | 32GB DDR5 1TB SSD | GeForce RTX 4060 8GB | RGB Backlit Thunderbolt4 Dynaudio FHD Webcam Win11Pro + HDMI Cable, Black'),
(66, 'MSI Pulse GL66', '1337.04', 'images/Products/laptop/msi/MSI Pulse GL66.jpg', 'laptop', 'msi', 'MSI Pulse GL66 15.6\" QHD 165Hz Gaming Laptop Intel Core i9-12900H RTX3070 16GB DDR5 1TB NVMe SSD Win11 - Black (12UGOK-825)'),
(67, 'Acer Nitro', '172.99', 'images/Products/monitor/acer/Acer Nitro.jpg', 'monitor', 'acer', 'Acer Nitro KG241Y Sbiip 23.8” Full HD (1920 x 1080) VA Gaming Monitor | AMD FreeSync Premium Technology | 165Hz Refresh Rate | 1ms (VRB) | ZeroFrame Design | 1 x Display Port 1.2 & 2 x HDMI 2.0,Black'),
(68, 'acer KB252Q E0bi', '99.99', 'images/Products/monitor/acer/acer KB252Q E0bi.jpg', 'monitor', 'acer', 'acer KB252Q E0bi 24.5\" IPS Full HD (1920 x 1080) Zero-Frame Gaming Office Monitor AMD FreeSync Technology Up to 100Hz Refresh 1ms (VRB) Low Blue Light Tilt HDMI & VGA Ports'),
(69, 'ASUS TUF Gaming VG27VH1B', '179.00', 'images/Products/monitor/asus/ASUS TUF Gaming VG27VH1B.jpg', 'monitor', 'asus', 'ASUS TUF Gaming VG27VH1B 27” Curved Monitor, 1080P Full HD, 165Hz (Supports 144Hz), Extreme Low Motion Blur, Adaptive-sync, FreeSync Premium, 1ms, Eye Care, HDMI D-Sub, BLACK'),
(70, 'LG UltraFine', '379.99', 'images/Products/monitor/lg/LG UltraFine.jpg', 'monitor', 'lg', 'LG UltraFine UHD 27-Inch 4K UHD 2160p Computer Monitor 27UN850-W, IPS with VESA DisplayHDR 400, AMD FreeSync, and USB-C, White,Silver'),
(71, 'LG UltraWide', '399.99', 'images/Products/monitor/lg/LG UltraWide.jpg', 'monitor', 'lg', 'LG UltraWide QHD 34-Inch Computer Monitor 34WP65C-B, VA with HDR 10 Compatibility and AMD FreeSync Premium, Black'),
(72, 'LG 27GP750-B 27” Ultragear', '299.99', 'images/Products/monitor/lg/LG 27GP750-B Ultragear.jpg', 'monitor', 'lg', 'LG 27GP750-B 27” Ultragear FHD (1920 x 1080) IPS Gaming Monitor w/ 1ms Response Time & 240Hz Refresh Rate, NVIDIA G-SYNC Compatible with AMD FreeSync Premium, Thin Bezel, Tilt/Height/Pivot Adjustable'),
(73, 'LG 32GS60QC-B Ultragear', '299.99', 'images/Products/monitor/lg/LG 32GS60QC-B Ultragear.jpg', 'monitor', 'lg', 'LG 32GS60QC-B Ultragear 32-inch Curved Gaming Monitor QHD (2560x1440) 180Hz 1ms 1000R AMD FreeSync HDR10 HDMIx2 DisplayPort Black'),
(74, 'SAMSUNG 32-Inch M7 (M70D) Series', '399.99', 'images/Products/monitor/samsung/SAMSUNG 32-Inch M7 (M70D) Series.jpg', 'monitor', 'samsung', 'SAMSUNG 32-Inch M7 (M70D) Series 4K UHD Smart Monitor with Streaming TV, Speakers, HDR10, USB-C, Multiple Ports, Gaming Hub, SolarCell Remote, Vision Accessibility Tools, LS32DM703UNXZA, 2024, White'),
(75, 'SAMSUNG 32-Inch S30B Series', '199.99', 'images/Products/monitor/samsung/SAMSUNG 32-Inch S30B Series.jpg', 'monitor', 'samsung', 'SAMSUNG 32-Inch S30B Series Business Flat Computer Monitor, 75Hz, Borderless Display, AMD FreeSync, Game Mode, Advanced Eye Care, HDMI and DisplayPort, LS32B304NWNXGO, 2024'),
(76, 'ViewFinity S50GC', '192.79', 'images/Products/monitor/samsung/ViewFinity S50GC.jpg', 'monitor', 'samsung', 'SAMSUNG 34\" ViewFinity S50GC Series Ultrawide QHD Monitor, 100Hz, 5ms, HDR10, AMD FreeSync, Eye Care, Borderless Design, PIP, PBP, LS34C50DGANXZA, 2023, Black'),
(77, 'Odyssey G9', '829.99', 'images/Products/monitor/samsung/Odyssey G9.jpg', 'monitor', 'samsung', 'SAMSUNG 49-Inch Odyssey G9 Series DQHD 1000R Curved Gaming Monitor, 1ms(GtG), VESA DisplayHDR 1000, 240Hz, AMD FreeSync Premium Pro, Height Adjustable Stand, LS49CG954ENXZA, 2024'),
(78, 'iPhone 14', '739.98', 'images/Products/phone/apple/iPhone 14.jpg', 'phone', 'apple', 'New Apple iPhone 14 (128 GB) - Starlight'),
(79, 'HONOR X7b', '157.00', 'images/Products/phone/honor/HONOR X7b.jpg', 'phone', 'honor', 'HONOR X7b 6GB RAM 256GB Internal storage 35W 6000mAH- Flowing Silver'),
(80, 'HONOR X8a', '139.00', 'images/Products/phone/honor/HONOR X8a.jpg', 'phone', 'honor', 'HONOR X8a Smartphone Unlocked, 100MP Triple Camera, 6.7\" 90Hz Fullview Display, 8 GB+128 GB, Android 12, Dual SIM'),
(81, 'HONOR X7c', '147.98', 'images/Products/phone/honor/HONOR X7c.jpg', 'phone', 'honor', 'HONOR X7c Dual SIM 8 RAM 256GB Midnight Black 4G - Middle East Version'),
(82, 'Honor X5 Plus', '79.98', 'images/Products/phone/honor/Honor X5 Plus.jpg', 'phone', 'honor', 'Honor X5 Plus Single SIM 4GB Ram+64GB ROM (6.56 Inches) (4G) - (Cyan Lake)'),
(83, 'Huawei Y6P', '139.98', 'images/Products/phone/huawei/Huawei Y6P.jpg', 'phone', 'huawei', 'Huawei Y6P Dual SIM - 64GB, 3GB RAM, 4G LTE - Phantom Purple'),
(84, 'Huawei Y7a', '159.98', 'images/Products/phone/huawei/Huawei Y7a.jpg', 'phone', 'huawei', 'Huawei Y7a Dual SIM - 128GB, 4GB RAM, 4G LTE - Crush Green'),
(85, 'Infinix Smart 9', '87.98', 'images/Products/phone/infinix/Infinix Smart 9.jpg', 'phone', 'infinix', 'Infinix Smart 9 (RAM: 4+4GB, ROM: 128GB), 6.7\" HD+ Display, 13MP Dual AI Rear Camera With Flashlight, 8MP Front Camera, 5000 mAh Battery, Dual Nano Sim, Type-C, Android 14 - Neo Titanium Color'),
(86, 'Infinix Smart 8', '79.98', 'images/Products/phone/infinix/Infinix Smart 8.jpg', 'phone', 'infinix', 'Infinix Smart 8 4G (Galaxy White, 4GB RAM, 64GB Storage) | up to 8 GB of RAM (4 GB + 4 GB Virtual) | 90 Hz Punch-hole Display | 50MP Dual Camera with Quad-LED Ring Flash | Helio G36 Mediatek Processor'),
(87, 'Nokia 2720 Flip', '35.98', 'images/Products/phone/nokia/Nokia 2720 Flip.jpg', 'phone', 'nokia', 'Nokia 2720 Flip Dual SIM Red 4GB 512MB RAM 4G LTE'),
(88, 'Nokia 6310', '33.98', 'images/Products/phone/nokia/Nokia 6310.jpg', 'phone', 'nokia', 'Nokia 6310 Mobile, Dual Sim, 8MB Internal Storage, 16MB Ram, 2G Network, Black'),
(89, 'Nokia 105 TA-1557', '13.98', 'images/Products/phone/nokia/Nokia 105 TA-1557.jpg', 'phone', 'nokia', 'Nokia 105 TA-1557 Dual Sim 2G Feature Phone, 2 GB Storage- Cyan'),
(90, 'Nokia 225', '24.00', 'images/Products/phone/nokia/Nokia 225.jpg', 'phone', 'nokia', 'Nokia 225 (Dual SIM, Keypad, 2.8in LCD Display, 2 Megapixel Camera, Black)'),
(91, 'OPPO A3x', '112.40', 'images/Products/phone/oppo/OPPO A3x.jpg', 'phone', 'oppo', 'OPPO A3x, 4GB Ram, 128GB Storage - Nebula Red'),
(92, 'Oppo Reno 12F 4G', '199.76', 'images/Products/phone/oppo/Oppo Reno 12F 4G.jpg', 'phone', 'oppo', 'Oppo Reno 12F 4G, 8GB Ram Snapdragon 685, 256GB Storage, 5000mAh & Dual SIM Slot - Matte Grey'),
(93, 'OPPO A18', '98.80', 'images/Products/phone/oppo/OPPO A18.jpg', 'phone', 'oppo', 'OPPO A18 (64-4GB) - Glowing Black'),
(94, 'realme c65', '141.00', 'images/Products/phone/realme/realme c65.jpg', 'phone', 'realme', 'realme c65 Smartphone 8+256 GB, 50MP AI Camera, 6.67 Inch Eye Comfort Display with 90Hz Refresh Rate, 45 W Fast Charge, 5000 mAh Solid Battery, NFC Supported, Starlight Gold'),
(95, 'realme 12x 5G', '169.00', 'images/Products/phone/realme/realme 12x 5G.jpg', 'phone', 'realme', 'realme 12x 5G 256GB 8GB Glowing Black INT+NFC'),
(96, 'Samsung Galaxy Z Flip6', '799.00', 'images/Products/phone/samsung/Samsung Galaxy Z Flip6.jpg', 'phone', 'samsung', 'Samsung Galaxy Z Flip6 (AI Phone) - 12GB RAM + 256GB Storage - Light Blue, 1 Year Local Warranty'),
(97, 'Samsung Galaxy A54 5G', '326.98', 'images/Products/phone/samsung/Samsung Galaxy A54 5G.jpg', 'phone', 'samsung', 'Samsung Galaxy A54 5G Dual SIM Mobile Phone, Android Operating System, 8GB RAM, 256GB Internal Storage, Lemon Ozymandias'),
(98, 'Samsung Galaxy A34', '245.98', 'images/Products/phone/samsung/Samsung Galaxy A34.jpg', 'phone', 'samsung', 'Samsung Galaxy A34 Dual SIM 8GB Ram+128GB ROM (6.5 Inches) (4G) - (Awesome Graphite)'),
(99, 'Samsung Galaxy A55 5G', '317.50', 'images/Products/phone/samsung/Samsung Galaxy A55 5G.jpg', 'phone', 'samsung', 'Samsung Galaxy A55 5G, Android Smartphone, Dual SIM Mobile Phone, 8GB RAM, 128GB Storage, Awesome Iceblue -1 Year Warranty/Local Version'),
(100, 'Redmi 13 Ocean Blue', '147.98', 'images/Products/phone/xiaomi/Redmi 13 Ocean Blue.jpg', 'phone', 'xiaomi', 'Redmi 13 Ocean Blue 8GB RAM 128GB ROM Mediatek helio G91 ultra processor| 6.79\" FHD+ 90Hz display | Triple Camera 108MP + 2MP, 13MP Front camera | 2-pin charger | 1 year manufacturer warranty'),
(101, 'Redmi Note 13 Pro', '19.80', 'images/Products/phone/xiaomi/Redmi Note 13 Pro.jpg', 'phone', 'xiaomi', 'Redmi Note 13 Pro 8GB RAM, 256 - Ultra-clear 200MP camera with OIS - 120Hz FHD+AMOLED display 6.67'),
(102, 'Xiaomi Redmi A3', '73.32', 'images/Products/phone/xiaomi/Xiaomi Redmi A3.jpg', 'phone', 'xiaomi', 'Xiaomi Redmi A3, 3GB RAM | 64GB ROM, 6.71 Inches HD+ 90HZ Display, 5000mAH Battery, 2 SIM, Dual Camera, (4G) Black | 1 year Local warranty'),
(103, 'Anker soundcore flare 2 bluetooth speaker', '41.58', 'images/Products/speaker/anker/Anker soundcore flare 2 bluetooth speaker.jpg', 'speaker', 'anker', 'Anker soundcore flare 2 bluetooth speaker, with ipx7 waterproof protection and 360 sound for backyard and beach party, 20w wireless speaker with partycast, eq adjustment, and 12-hour playtime, black'),
(104, 'Sub Mini Bluetooth Speaker', '3.58', 'images/Products/speaker/generic/Sub Mini Bluetooth Speaker.jpg', 'speaker', 'generic', 'Sub Mini Bluetooth Speaker – Portable Wireless Subwoofer and Rechargeable Battery for Smartphones, Tablets, and Computers V1 (Gold)'),
(105, 'KPR Night light bluetooth speaker', '3.00', 'images/Products/speaker/generic/KPR Night light bluetooth speaker.jpg', 'speaker', 'generic', 'KPR Night light bluetooth speaker, portable wireless bluetooth speakers, touch control bedside table light, outdoor speakers bluetooth, best gifts for girl, boy, baby'),
(106, 'MARSGAMING MSRGB, Powerful Bluetooth Speaker', '13.00', 'images/Products/speaker/marsgaming/MARSGAMING MSRGB, Powerful Bluetooth Speaker.jpg', 'speaker', 'marsgaming', 'MARSGAMING MSRGB, Powerful Bluetooth Speaker 15W, RGB Full Mesh, 2 Active Drivers, Black'),
(107, 'Oraimo Rover 12W FM Wireless Speaker', '18.98', 'images/Products/speaker/oraimo/Oraimo Rover 12W FM Wireless Speaker.jpg', 'speaker', 'oraimo', 'Oraimo Rover 12W FM Wireless Speaker, OBS-53D - Black'),
(108, 'Redragon GS520 Anvil RGB Desktop Speakers', '25.98', 'images/Products/speaker/redragon/Redragon GS520 Anvil RGB Desktop Speakers.jpg', 'speaker', 'redragon', 'Redragon GS520 Anvil RGB Desktop Speakers, 2.0 Channel PC Computer Stereo Speaker with 6 Colorful LED Modes'),
(109, 'Redragon GS700 Toccata RGB 2.1 Gaming Subwoofer Speakers', '35.30', 'images/Products/speaker/redragon/Redragon GS700 Toccata RGB 2.1 Gaming Subwoofer Speakers.jpg', 'speaker', 'redragon', 'Redragon GS700 Toccata RGB 2.1 Gaming Subwoofer Speakers – Aux 3.5mm Stereo Surround – Heavy Bass sound loudspeakers for computer PC'),
(110, 'iPhone 16', '895.00', 'images/Products/phone/apple/iPhone 16.jpg', 'phone', 'apple', 'Apple iPhone 16 (128 GB) - Black'),
(111, 'Nokia g60 5g', '159.98', 'images/Products/phone/nokia/Nokia g60 5g.jpg', 'phone', 'nokia', 'Nokia G60 5G smartphone, 6.58\' HD+ 120Hz display, 50MP AI rear camera, 8MP front camera, 6GB RAM, 128GB storage - Grey'),
(112, 'SAMSUNG 27\" T35F Series', '149.99', 'images/Products/monitor/samsung/SAMSUNG 27-inch T35F Series.jpg', 'monitor', 'samsung', 'SAMSUNG 27\" T35F Series FHD 1080p Computer Monitor, 75Hz, IPS Panel, HDMI, VGA (D-Sub), 3-Sided Border-Less, FreeSync, LF27T350FHNXZA'),
(113, 'MSI MPG GUNGNIR 300R Airflow White', '179.00', 'images/Products/case/msi/MSI MPG GUNGNIR 300R Airflow White.jpg', 'case', 'msi', 'MSI MPG GUNGNIR 300R Airflow White - Premium Mid-Tower Gaming PC Case - Tempered Glass Side Panel - ARGB 120mm Fans - Liquid Cooling Support up to 360mm Radiator - White Color Case');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(100) NOT NULL,
  `card_num` bigint(20) DEFAULT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `password`, `card_num`, `image`) VALUES
(1, 'Mohamed Eltelb', 'mohamed@gmail.com', 'Mohamed123', 5234567812345678, 'us/mohamed.jpg'),
(2, 'Ahmed', 'ahmed@gmail.com', 'Ahmed123', 1234567812345678, 'us/ahmed.jpg'),
(3, 'Mostafa', 'mostafa@gmail.com', 'Mostafa123', 2234567812345678, 'us/khalil.png'),
(4, 'Abdo', 'abdo@gmail.com', 'Abdo123', 3234567812345678, 'us/abdo.png'),
(5, 'Elsaed', 'elsaed@gmail.com', 'Elsaed123', 4234567812345678, 'us/shadow.jpg'),
(6, 'Esmael', 'esmael@gmail.com', 'Esmael123', 1234567891234567, 'us/Esmael.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=86;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=125;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
