<?php include 'config.php';
session_start();
$brand = isset($_GET['brand']) ? $_GET['brand'] : 'all';
$query = $brand === 'all'
    ? "SELECT * FROM products"
    : "SELECT * FROM products WHERE brand='$brand'";
$result = $conn->query($query);
$user_id = $_SESSION['user_id'];
if (!isset($user_id)) {
    header('location:login-out/login-out.php');
}
;
if (isset($_GET['logout'])) {
    unset($user_id);
    session_destroy();
    header('location:login-out/login-out.php');
}
;
if (isset($_POST['add_to_cart'])) {
    $product_name = $_POST['product_name'];
    $product_price = $_POST['product_price'];
    $product_image = $_POST['product_image'];
    $product_quantity = 1;
    $select_cart = mysqli_query($conn, "SELECT * FROM `cart` WHERE name = '$product_name' AND user_id = '$user_id'") or
        die('query failed');
    if (mysqli_num_rows($select_cart) > 0) {
        $message[] = 'Product already added to the cart';
    } else {
        mysqli_query($conn, "INSERT INTO `cart`(user_id, name, price, image, quantity) VALUES('$user_id', '$product_name',
    '$product_price', '$product_image', '$product_quantity')") or die('query failed');
        $message[] = 'Product added to the cart';
    }

}
;
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/iconoir-icons/iconoir@main/css/iconoir.css" />
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/remixicon/3.5.0/remixicon.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="product.css">

    <title>Flex Store</title>
    <script>
        window.addEventListener('load', function () {
            const isDarkMode = localStorage.getItem('darkMode') === 'true';
            const body = document.body;

            if (isDarkMode) {
                body.classList.add('dark');
            } else {
                body.classList.remove('dark');
            }
        });
    </script>

</head>

<body>

    <?php
    if (isset($message)) {
        foreach ($message as $message) {
            echo '<div style=" background-color: var(--dark);
      color: var(--light);
      padding: 10px;
      text-align: center;" class="message" onclick="this.remove();">' . $message . '</div>';

        }
        unset($message);
    }

    ?>
    <?php
    $select_user = mysqli_query($conn, "SELECT * FROM `user` WHERE id = '$user_id'") or die('query failed');
    if (mysqli_num_rows($select_user) > 0) {
        $fetch_user = mysqli_fetch_assoc($select_user);
    }
    ;
    ?>
    <!-- Sidebar -->
    <div class="sidebar">
        <a href="index.php" class="logo">
            <svg viewBox="0 0 300 300" class="font">
                <!---->
                <defs data-v-fde0c5aa="">
                    <!---->
                </defs>
                <g data-v-fde0c5aa="" id="9455a294-f326-4286-948e-cfccc4a386d7" fill="#01D8FD"
                    transform="matrix(16.081870986272108,0,0,16.081870986272108,21.988304418690916,61.49098806547728)">
                    <path
                        d="M6.43 2.23L6.43 2.23L3.46 2.23C3.19 2.23 2.98 2.42 2.98 2.69L2.98 4.56C2.98 4.82 3.19 5.03 3.46 5.03L5.56 5.03C5.81 5.03 6.02 4.82 6.02 4.56C6.02 4.30 5.81 4.09 5.56 4.09L3.92 4.09L3.92 3.15L6.43 3.15C6.69 3.15 6.90 2.94 6.90 2.69C6.90 2.42 6.69 2.23 6.43 2.23ZM5.56 5.96L5.56 5.96L3.46 5.96C3.19 5.96 2.98 6.17 2.98 6.43L2.98 10.18C2.98 10.43 3.19 10.64 3.46 10.64C3.71 10.64 3.92 10.43 3.92 10.18L3.92 6.90L5.56 6.90C5.81 6.90 6.02 6.69 6.02 6.43C6.02 6.17 5.81 5.96 5.56 5.96ZM2.04 10.18L2.04 10.18L2.04 1.29L6.43 1.29C6.69 1.29 6.90 1.08 6.90 0.81C6.90 0.56 6.69 0.35 6.43 0.35L1.58 0.35C1.32 0.35 1.12 0.56 1.12 0.81L1.12 10.18C1.12 10.43 1.32 10.64 1.58 10.64C1.83 10.64 2.04 10.43 2.04 10.18ZM13.80 0.71L13.80 0.71C12.82 0.38 12.14 0.27 11.30 0.31C8.41 0.45 7.18 3.99 9.21 5.77C10.51 6.90 11.90 6.79 11.96 7.45C12.04 8.15 10.15 8.01 9.07 7.22C8.58 6.87 8.04 7.63 8.53 7.98C9.45 8.65 10.58 8.88 11.49 8.82C12.25 8.76 12.94 8.19 12.89 7.41C12.80 5.92 11.06 6.16 9.84 5.07C8.83 4.20 9.03 2.73 9.79 1.93C10.71 0.91 12.22 1.15 13.48 1.60C14.07 1.81 14.38 0.91 13.80 0.71ZM8.34 9.97L8.34 9.97C8.89 10.26 9.44 10.44 9.91 10.54C12.53 11.17 14.80 9.97 14.80 7.41C14.80 4.80 11.73 4.24 11.21 3.85C10.75 3.49 11.12 2.62 13.23 3.47C13.80 3.71 14.14 2.84 13.59 2.62C10.11 1.20 9.52 3.68 10.64 4.56C11.35 5.14 13.87 5.49 13.87 7.41C13.87 10.00 10.95 10.29 8.79 9.14C8.25 8.86 7.81 9.69 8.34 9.97ZM11.41 7.90L11.41 7.90L11.41 7.90L11.41 7.90Z">
                    </path>
                </g>
                <!----><!---->
            </svg>
            <div class="logo-name"><span>Flex</span>Store</div>
        </a>
        <ul class="side-menu">
            <li class="special"><a href="index.php"> <i class='bx bx-home-alt icon'></i>Home</a></li>
            <li class="special"><a href="shop.php"><i class="fa-solid fa-shop"></i>Shop</a></li>
            <li class="special"><a href="cart.php"><i class='bx bx-cart'></i>Cart</a></li>
            <li class="special"><a href="settings.php"><i class='bx bx-cog'></i>Settings</a></li>
            <li class="special"><a href="about.php"><i class='bx bx-info-circle'></i>About Us</a></li>
        </ul>

    </div>
    <!-- End of Sidebar -->

    <!-- Main Content -->
    <div class="content">
        <!-- Navbar -->
        <nav>
            <i class='bx bx-menu'></i>

            <!-- search -->
            <form method="post" action="res.php">
                <div class="form-input">
                    <input type="search" placeholder="Search..." name="search" required>
                    <button class="search-btn" type="submit">
                        <i class='bx bx-search'></i>
                    </button>
                </div>
            </form>
            <!-- End of search -->

            <div class="profile">
                <img class="user-pic" src="<?php echo $fetch_user['image']; ?>" onclick="toggleMenu()">
                <div class="sub-menu-wrap" id="subMenu">
                    <div class="sub-menu">
                        <div class="user-info">
                            <img src="<?php echo $fetch_user['image']; ?>">

                            <h2><?php echo $fetch_user['name']; ?></h2>
                        </div>
                        <hr>
                        <a class="sub-menu-link" href="profile.php?user_id=<?php echo $fetch_user['id']; ?>">
                            <i class='bx bx-user'></i>
                            <p>Profile</p>
                        </a>

                        <a href="index.php?logout=<?php echo $user_id; ?>"
                            onclick="return confirm('Are you sure you want to logout?');" class="sub-menu-link">
                            <i class='bx bx-log-out-circle'></i>
                            <p>logout</p>
                        </a>
                    </div>
                </div>
            </div>
        </nav>
        <!-- End of Navbar -->

        <main>
            <div class="insights" style="grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));">
                <?php
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        ?>
                        <div class="card product-item" data-id="<?php echo $row['id']; ?>"
                            data-name="<?php echo $row['name']; ?>" data-price="<?php echo $row['price']; ?>"
                            data-image="<?php echo $row['image']; ?>" data-description="<?php echo $row['description']; ?>"
                            data-brand="<?php echo $row['brand']; ?>" data-category="<?php echo $row['category']; ?>">
                            <div class="img">
                                <img src="<?php echo $row['image']; ?>" alt="<?php echo $row['name']; ?>"
                                    style="height: 300px;">
                            </div>
                            <div class="head">
                                <h1 class="title"><?php echo $row['name']; ?></h1>
                            </div>
                            <p class="salary"><?php echo '$' . $row['price']; ?></p>
                        </div>
                        <?php
                    }
                } else {
                    echo '<p style="text-align: center;">No products found for this brand.</p>';
                }
                ?>
            </div>
        </main>
        <!-- Product Popup -->
        <div id="product-popup" class="product-page" style="display: none;">
            <div class="product-container">
                <div class="product-photo">
                    <img id="product-image" src="" alt="Product Image">
                </div>
                <div class="product-details">
                    <h1 id="product-description" class="product-description"></h1>
                    <p class="product-brand">Brand: <strong id="product-brand"></strong></p>
                    <p class="product-category">Category: <strong id="product-category"></strong></p>
                    <p id="product-price" class="product-price"></p>

                    <!-- Hidden Form for adding to cart -->
                    <form method="post" action="">
                        <input type="hidden" name="product_name" id="popup-product-name">
                        <input type="hidden" name="product_price" id="popup-product-price">
                        <input type="hidden" name="product_image" id="popup-product-image">
                        <input type="hidden" name="user_id" value="<?php echo $user_id; ?>">
                        <!-- Ensure user ID is available -->
                        <div class="action-buttons">
                            <button type="submit" name="add_to_cart" class="add-to-cart">Add to Cart</button>
                            <button id="close-popup">Close</button>
                        </div>
                    </form>

                </div>
            </div>
        </div>

        <script>
            // Show product details in the popup
            document.querySelectorAll('.product-item').forEach(item => {
                item.addEventListener('click', function () {
                    const productName = this.getAttribute('data-name');
                    const productPrice = this.getAttribute('data-price');
                    const productImage = this.getAttribute('data-image');
                    const productDescription = this.getAttribute('data-description');
                    const productBrand = this.getAttribute('data-brand');
                    const productCategory = this.getAttribute('data-category');

                    // Populate popup
                    document.getElementById('popup-product-name').value = productName;
                    document.getElementById('popup-product-price').value = productPrice;
                    document.getElementById('popup-product-image').value = productImage;
                    document.getElementById('product-image').src = productImage;
                    document.getElementById('product-description').textContent = productDescription;
                    document.getElementById('product-brand').textContent = productBrand;
                    document.getElementById('product-category').textContent = productCategory;
                    document.getElementById('product-price').textContent = '$' + productPrice;

                    // Show popup
                    document.getElementById('product-popup').style.display = 'flex';
                });
            });

            // Close the popup when clicking the close button
            document.getElementById('close-popup').addEventListener('click', () => {
                event.preventDefault();
                document.getElementById('product-popup').style.display = 'none';
            });

        </script>


        <script>
            let subMenu = document.getElementById("subMenu");
            function toggleMenu() {
                if (subMenu.classList.contains("open-menu")) {
                    subMenu.classList.remove("open-menu");
                } else {
                    subMenu.classList.add("open-menu");
                }
            }

        </script>
        <script>

            const messages = document.querySelectorAll('.message');

            messages.forEach(message => {
                setTimeout(() => {
                    message.remove();
                }, 2000);
            });
        </script>
        <script src="https://kit.fontawesome.com/5b9e84079b.js" crossorigin="anonymous"></script>
        <script src="index.js"></script>

</body>

</html>