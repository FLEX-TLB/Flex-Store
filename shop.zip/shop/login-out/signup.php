<?php
include 'config.php';
session_start();

if (isset($_POST['submit'])) {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $card_num = mysqli_real_escape_string($conn, $_POST['card_num']);

    // Handle image upload
    $image = 'images/profile.jpg'; // Default path for the uploaded image

    if (isset($_FILES['image']['name']) && $_FILES['image']['name'] != '') {
        $image_name = $_FILES['image']['name'];
        $image_tmp_name = $_FILES['image']['tmp_name'];
        $image_folder = 'images/profile.jpg';

        // Move the uploaded file to the target location
        if (!move_uploaded_file($image_tmp_name, $image_folder)) {
            $_SESSION['message'] = 'Failed to upload image!';
            header('location:login-out.php');
            exit();
        }
    }

    // Check if the user already exists
    $select = mysqli_query($conn, "SELECT * FROM `user` WHERE email = '$email'") or die('query failed');

    if (mysqli_num_rows($select) > 0) {
        $_SESSION['message'] = 'User already exists!';
        header('location:login-out.php');
        exit();
    } else {
        // Insert the new user into the database
        $insert_query = "INSERT INTO `user` (name, email, password, card_num, image) VALUES ('$name', '$email', '$password', '$card_num', '$image')";
        mysqli_query($conn, $insert_query) or die('query failed');

        $_SESSION['message'] = 'Registered successfully!';
        header('location:login-out.php');
        exit();
    }
}
?>