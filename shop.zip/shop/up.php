<?php

include('config.php');

if (isset($_POST['update'])) {
    // Get form data
    $ID = $_POST['id'];
    $NAME = mysqli_real_escape_string($conn, $_POST['name']);
    $PRICE = mysqli_real_escape_string($conn, $_POST['price']);
    $CATEGORY = mysqli_real_escape_string($conn, $_POST['category']);
    $BRAND = mysqli_real_escape_string($conn, $_POST['brand']);
    
    // Handle image upload if a new image is provided
    if (isset($_FILES['image']) && $_FILES['image']['error'] === 0) {
        $image_location = $_FILES['image']['tmp_name'];
        $image_name = $_FILES['image']['name'];

        // Define the target folder for each category and brand
        $upload_folder = 'images/Products/' . $CATEGORY . '/' . $BRAND . '/';

        // Create the folder if it doesn't exist
        if (!file_exists($upload_folder)) {
            mkdir($upload_folder, 0777, true); // Create the folder with write permissions
        }

        // Define the full path where the image will be saved
        $image_up = $upload_folder . $image_name;

        // Move the uploaded image to the target folder
        if (move_uploaded_file($image_location, $image_up)) {
            // Update the product in the database with the new image path, category, and brand
            $update = "UPDATE products SET name='$NAME', price='$PRICE', category='$CATEGORY', brand='$BRAND', image='$image_up' WHERE id='$ID'";
            if (mysqli_query($conn, $update)) {
                header('Location: products.php');
                exit;
            } else {
                echo "Error updating product: " . mysqli_error($conn);
            }
        } else {
            echo "Failed to upload image.";
        }
    } else {
        // No image uploaded, just update name, price, category, and brand
        $update = "UPDATE products SET name='$NAME', price='$PRICE', category='$CATEGORY', brand='$BRAND' WHERE id='$ID'";
        if (mysqli_query($conn, $update)) {
            header('Location: products.php');
            exit;
        } else {
            echo "Error updating product: " . mysqli_error($conn);
        }
    }
}

?>
