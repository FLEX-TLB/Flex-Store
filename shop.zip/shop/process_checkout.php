<?php
if (isset($_POST['buy'])) {
    // Connect to database
    include 'config.php'; // Update with your DB connection script
    session_start();
    
    // Retrieve form data
    $user_id = $_SESSION['user_id']; // Ensure user session is set
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $city = mysqli_real_escape_string($conn, $_POST['city']);
    $state = mysqli_real_escape_string($conn, $_POST['state']);
    $zip = mysqli_real_escape_string($conn, $_POST['zip']);
    $cardNumber = mysqli_real_escape_string($conn, $_POST['cardNumber']);
    $expiry = mysqli_real_escape_string($conn, $_POST['expiry']);
    $cvv = mysqli_real_escape_string($conn, $_POST['cvv']);

    // Validate user
    $select_user = mysqli_query($conn, "SELECT * FROM `user` WHERE id = '$user_id'") or die('Query failed');
    if (mysqli_num_rows($select_user) > 0) {
        $fetch_user = mysqli_fetch_assoc($select_user);
    } else {
        die('User not found');
    }

    // Check card details
    $ck_select = mysqli_query($conn, "SELECT * FROM `user` WHERE name = '$fetch_user[name]' AND card_num = '$cardNumber'") or die('Query failed');

    // Check cart contents
    $checkCartQuery = "SELECT COUNT(*) as count FROM cart WHERE user_id = '$user_id'";
    $result = mysqli_query($conn, $checkCartQuery);

    if ($result) {
        $row = mysqli_fetch_assoc($result);
        $cartItemCount = $row['count'];

        if ($cartItemCount == 0) {
            $message = 'Cart is empty';
        } else {
            if (mysqli_num_rows($ck_select) > 0) {
                $message = 'Purchased Successfully!';

                // Clear cart after purchase
                $clearCartQuery = "DELETE FROM cart WHERE user_id = '$user_id'";
                mysqli_query($conn, $clearCartQuery) or die('Failed to clear cart');
            } else {
                $message = 'Wrong Data!';
            }
        }
    } else {
        $message = 'Error checking cart';
    }

    echo $message;
}
?>
